import unittest, json, urllib.request, urllib.error, os
import api_server as A
D = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data", "samples")
def _rd(f):
    with open(os.path.join(D, f), "rb") as fh: return fh.read()
def call(b, m, path, role="department_officer", user="u1", body=None, district=None):
    h = {"X-User": user, "X-Role": role}; 
    if district: h["X-District"] = district
    r = urllib.request.Request(b + path, data=body, headers=h, method=m)
    try:
        with urllib.request.urlopen(r) as x: return x.status, json.loads(x.read())
    except urllib.error.HTTPError as e: return e.code, json.loads(e.read())
class T(unittest.TestCase):
    @classmethod
    def setUpClass(c): c.s = A.serve(0); c.b = f"http://127.0.0.1:{c.s.server_address[1]}"
    @classmethod
    def tearDownClass(c): c.s.shutdown()
    def up(self, f, **kw): return call(self.b, "POST", "/ingest?source=SAMPLE&ref_year=2026", body=_rd(f), **kw)
    def test_upload_validate_harmonise_store_retrieve(self):
        code, r = self.up("sample_dept_upload_good.csv"); self.assertEqual(code, 201)
        self.assertEqual([s["stage"] for s in r["steps"]], ["parse", "pii_block", "schema_validation", "harmonisation", "store"])
        self.assertEqual(r["steps"][3]["duplicates_removed"], 2); self.assertEqual(r["steps"][3]["district_codes_remapped"], [101])
        code, card = call(self.b, "GET", f"/ingest/{r['upload_id']}/evidence-card/102", role="auditor")
        self.assertEqual(code, 200); self.assertTrue(card["mock"]); self.assertIsNone(card["supports"]); self.assertEqual(card["provenance"]["sha256"], r["meta"]["sha256"])
    def test_lgd_recode_applied(self):
        code, r = self.up("sample_dept_upload_good.csv"); code, c102 = call(self.b, "GET", f"/ingest/{r['upload_id']}/evidence-card/102")
        self.assertEqual(code, 200)   # 101 rows from 2025-04 re-coded into 102
        self.assertEqual(call(self.b, "GET", f"/ingest/{r['upload_id']}/evidence-card/101")[0], 404)
    def test_pii_upload_refused(self):
        code, r = self.up("sample_dept_upload_with_pii.csv"); self.assertEqual((code, r["stage"]), (422, "pii_block"))
    def test_schema_drift_refused(self):
        code, r = self.up("sample_dept_upload_schema_drift.csv"); self.assertEqual((code, r["stage"]), (422, "schema_validation"))
    def test_only_authorised_roles_can_upload(self):
        for role in ("district_officer", "auditor", "", "superuser"): self.assertEqual(self.up("sample_dept_upload_good.csv", role=role)[0], 403)
    def test_same_file_same_hash(self):
        a = self.up("sample_dept_upload_good.csv")[1]["upload_id"]; b = self.up("sample_dept_upload_good.csv")[1]["upload_id"]; self.assertEqual(a, b)
    def test_garbage_bytes_rejected_not_crashed(self):
        code, r = call(self.b, "POST", "/ingest", body=b"\x00\x01\x02not,csv\n\xff\xfe")
        self.assertIn(code, (422,)); self.assertFalse(r["accepted"])
    def test_ingest_events_in_audit_chain(self):
        self.up("sample_dept_upload_with_pii.csv"); code, a = call(self.b, "GET", "/audit", role="auditor"); self.assertTrue(a["chain_valid"])
if __name__ == "__main__": unittest.main()
