"""Benchmark of pipeline.run() on synthetic data (pandas, CSV output, in memory). Run: python bench_pipeline.py"""
import time, os, tempfile, platform, numpy as np, pandas as pd, pipeline as P, tracemalloc
rng = np.random.default_rng(0)
def make(n):
    months = [f"{2023+i//12}-{i%12+1:02d}" for i in range(36)]
    df = pd.DataFrame({"district_code": rng.integers(1, 32, n).astype("int64"), "period": rng.choice(months, n),
                       "records": rng.integers(1, 500, n).astype("int64"), "source": "synthetic"})
    return df
print("rows | run() seconds | rows/sec | peak MB | published")
for n in (10_000, 100_000, 1_000_000):
    df = make(n); out = os.path.join(tempfile.mkdtemp(), "out.csv")
    tracemalloc.start(); t = time.time(); r = P.run(df, out); dt = time.time() - t; peak = tracemalloc.get_traced_memory()[1] / 1e6; tracemalloc.stop()
    print(f"{n:>9,} | {dt:6.2f} | {n/dt:>10,.0f} | {peak:6.0f} | {r['published']}")
# recovery: inject failure mid-write on 1M rows; last good file must survive untouched
df = make(1_000_000); out = os.path.join(tempfile.mkdtemp(), "out.csv"); P.run(df.head(1000), out); before = open(out).read()
for stage in ("aggregate", "write"):
    try: P.run(df, out, fail_at=stage)
    except RuntimeError: pass
    assert open(out).read() == before and len(os.listdir(os.path.dirname(out))) == 1
print("recovery: injected failure at aggregate and write on 1M rows; last good output unchanged, no temp files left")
print(platform.platform(), os.cpu_count(), "cpu(s)")
