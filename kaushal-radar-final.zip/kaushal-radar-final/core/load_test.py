"""Concurrency test for the local API prototype (stdlib ThreadingHTTPServer, single process).
Fires N concurrent clients x M requests mixing reads, gate checks, ledger writes and denied calls; reports latency and errors,
then verifies the audit hash chain is still valid under load.  Prototype numbers on one laptop, not a production load test."""
import sys, time, json, threading, statistics, urllib.request, urllib.error
import api_server as A
srv = A.serve(0); B = f"http://127.0.0.1:{srv.server_address[1]}"
def call(m, path, role, user="load", district=None, body=None):
    h = {"X-User": user, "X-Role": role, "Content-Type": "application/json"}
    if district: h["X-District"] = district
    req = urllib.request.Request(B + path, data=json.dumps(body).encode() if body is not None else None, headers=h, method=m)
    t = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=30) as r: code = r.status; r.read()
    except urllib.error.HTTPError as e: code = e.code; e.read()
    except Exception: code = -1
    return code, (time.perf_counter() - t) * 1000
MIX = [("GET", "/districts/raichur/indicators", "department_officer", None, 200),
       ("GET", "/districts/bidar/gate", "department_officer", None, 200),
       ("GET", "/districts/mysuru/indicators", "district_officer", None, 403),   # must be denied
       ("POST", "/ledger", "department_officer", {"district": "raichur", "decision": "ACCEPT_FOR_INVESTIGATION"}, 409)]  # gate blocks
def worker(n, out):
    for i in range(n):
        m, p, role, body, expect = MIX[i % len(MIX)]
        code, ms = call(m, p, role, user=f"u{threading.get_ident()%1000}", body=body, district=None)
        out.append((code, ms, expect))
def run(clients, reqs):
    out = []; ts = [threading.Thread(target=worker, args=(reqs, out)) for _ in range(clients)]
    t0 = time.perf_counter(); [t.start() for t in ts]; [t.join() for t in ts]; wall = time.perf_counter() - t0
    lat = sorted(x[1] for x in out); ok = sum(1 for c, _, e in out if c == e)
    p = lambda q: lat[min(len(lat) - 1, int(q * len(lat)))]
    print(f"{clients:>4} clients x {reqs} req = {len(out):>5} | {len(out)/wall:7.0f} req/s | p50 {p(.5):6.1f} ms  p95 {p(.95):6.1f} ms  p99 {p(.99):6.1f} ms | correct status {ok}/{len(out)}")
    return ok == len(out)
print("Kaushal Radar API concurrency test (local, single process)")
res = [run(c, 20) for c in (1, 10, 50, 100, 200)]; allok = all(res)
code, _ = call("GET", "/audit", "auditor", "auditor1")
chain = json.loads(urllib.request.urlopen(urllib.request.Request(B + "/audit", headers={"X-User": "a", "X-Role": "auditor"})).read())
print("audit chain valid after load:", chain["chain_valid"], "| entries:", chain["entries"])
print("RESULT:", "PASS" if allok and chain["chain_valid"] else "FAIL")
srv.shutdown()
