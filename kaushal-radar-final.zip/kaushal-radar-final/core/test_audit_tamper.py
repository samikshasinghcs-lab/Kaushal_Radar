import unittest, copy
import decision_engine as E, security as S
class T(unittest.TestCase):
    def mk(self):
        s = S.AuditedStore()
        for i in range(5): s.access(f"u{i}", "auditor", "read_indicators", "raichur")
        return s.ledger
    def test_clean_chain_verifies(self): self.assertTrue(self.mk().verify())
    def test_edit_detected(self):
        l = self.mk(); l.rows[2]["body"]["actor"] = "someone_else"; self.assertFalse(l.verify())
    def test_delete_detected(self):
        l = self.mk(); del l.rows[2]; self.assertFalse(l.verify())
    def test_reorder_detected(self):
        l = self.mk(); l.rows[1], l.rows[3] = l.rows[3], l.rows[1]; self.assertFalse(l.verify())
    def test_truncate_tail_is_NOT_detected_without_external_anchor(self):
        """Known limit, documented: dropping the newest entries leaves a valid shorter chain. Production needs an external anchor (WORM store / periodic head-hash publication)."""
        l = self.mk(); l.rows.pop(); self.assertTrue(l.verify())
    def test_forged_role_label_unknown_role_denied(self):
        for r in ("root", "ADMINISTRATOR ", "administrator;", None): self.assertFalse(S.authorize(r, "decide"))
if __name__ == "__main__": unittest.main()
