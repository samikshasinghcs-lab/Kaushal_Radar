"""Departmental file ingestion (prototype). upload CSV -> PII block -> schema/quality validation -> LGD harmonisation
-> atomic store (sha256) -> evidence-card generation -> retrieval.  Sample files are SYNTHETIC and labelled so.
Source provenance is kept on every stored object; nothing is merged with other sources."""
import io, os, json, hashlib, tempfile
import pandas as pd
import pipeline as P, security as S, decision_engine as E

STORE_DIR = os.environ.get("KR_STORE_DIR") or tempfile.mkdtemp(prefix="kr_store_")
INDEX = {}   # upload_id -> metadata (in-memory; production: database)

def ingest_csv(raw: bytes, source: str, ref_year: int, uploader: str, label_mock: bool = True):
    """Returns dict with stage-by-stage report. Never raises on bad input: rejects with a reason."""
    steps = []
    try: df = pd.read_csv(io.BytesIO(raw), encoding="utf-8-sig")
    except Exception as e: return {"accepted": False, "stage": "parse", "reason": f"unreadable CSV: {type(e).__name__}"}
    steps.append({"stage": "parse", "ok": True, "rows": len(df)})
    pii = S.reject_pii(list(df.columns))
    if pii: return {"accepted": False, "stage": "pii_block", "reason": f"personal-data columns refused: {pii}", "steps": steps}
    steps.append({"stage": "pii_block", "ok": True})
    rep = P.validate(df)
    if rep["errors"]: return {"accepted": False, "stage": "schema_validation", "reason": rep["errors"], "steps": steps}
    steps.append({"stage": "schema_validation", "ok": True, "warnings": rep["warnings"], "stale": rep["stale"]})
    n_in = len(df); df = df.drop_duplicates(["district_code", "period"], keep="last"); n_dup = n_in - len(df)
    before = set(df.district_code); df = P.harmonise(df); remapped = sorted(before - set(df.district_code))
    steps.append({"stage": "harmonisation", "ok": True, "duplicates_removed": n_dup, "district_codes_remapped": remapped})
    agg = df.groupby("district_code", as_index=False).records.sum().sort_values("district_code")
    body = agg.to_csv(index=False).encode(); digest = hashlib.sha256(body).hexdigest(); uid = digest[:12]
    path = os.path.join(STORE_DIR, f"{uid}.csv"); fd, tmp = tempfile.mkstemp(dir=STORE_DIR)
    with os.fdopen(fd, "wb") as f: f.write(body)
    os.replace(tmp, path)
    steps.append({"stage": "store", "ok": True, "sha256": digest})
    meta = {"upload_id": uid, "source": source, "ref_year": ref_year, "period_min": df.period.min(), "period_max": df.period.max(),
            "uploader": uploader, "sha256": digest, "rows_in": n_in, "districts": int(agg.district_code.nunique()), "mock": label_mock,
            "stale": rep["stale"], "path": path}
    INDEX[uid] = meta
    return {"accepted": True, "upload_id": uid, "steps": steps, "meta": {k: v for k, v in meta.items() if k != "path"}}

def evidence_card(uid: str, district_code: int):
    m = INDEX.get(uid)
    if not m: return None
    agg = pd.read_csv(m["path"]); row = agg[agg.district_code == district_code]
    if row.empty: return {"error": "district not present in this upload"}
    c = E.card("departmental_feed", f"{m['source']} (SAMPLE)" if m["mock"] else m["source"], int(row.records.iloc[0]), None, m["ref_year"], mock=m["mock"])
    c.update({"supports": None, "supports_note": "Direction not asserted: needs validated denominator and independent corroboration",
              "provenance": {"upload_id": uid, "sha256": m["sha256"], "periods": f"{m['period_min']}..{m['period_max']}", "uploader": m["uploader"]},
              "unit": "records (count); not a rate, not a population estimate"})
    return c
