"""Kaushal Radar API prototype (stdlib only). Local demo of the draft OpenAPI spec: indicators, corroboration gate, decision ledger, audit.
Real data: indicators_v2.csv (DES Karnataka tables). Gate evidence for 'low_vacancy' / 'high_vacancy' scenarios is MOCK and labelled so.
Auth here is a header stub (X-User, X-Role, X-District). Production needs State SSO, tokens and key management."""
import json, threading, http.server, urllib.parse, functools
import pandas as pd
import decision_engine as E, security as S, ingest as I

DF = pd.read_csv("indicators_v2.csv").set_index("key")
REG = DF["Grand Total"].to_dict(); DEN = DF["implied_pop"].to_dict()
RANKS = E.ranks(E.dgpi(REG, DEN)); STORE = S.AuditedStore()

@functools.lru_cache(maxsize=64)
def _stab(key): return E.rank_stability(REG, DEN, key, draws=500)   # seeded and data is static, so cache per district

def gate_for(key, scenario="real"):
    cards = {"graduate_demand": E.card("graduate_demand", "Yuva Nidhi 2025 (real)", 1, True, 2025, mock=False)}
    if scenario in ("low_vacancy", "high_vacancy"): cards = E.mock_cards(scenario)
    stab = _stab(key)
    g = E.gate(key, RANKS[key] <= 8, stab, cards); g["evidence_is_mock"] = scenario != "real"; return g

class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def send(self, code, obj):
        b = json.dumps(obj).encode(); self.send_response(code); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def who(self): return self.headers.get("X-User", "anonymous"), self.headers.get("X-Role", ""), self.headers.get("X-District")
    def auth(self, action, district=None):
        u, r, ud = self.who()
        try: STORE.access(u, r, action, district, ud); return True
        except PermissionError as e: self.send(403, {"error": "forbidden", "detail": str(e)}); return False
    def do_GET(self):
        p = urllib.parse.urlparse(self.path); parts = [x for x in p.path.split("/") if x]; q = urllib.parse.parse_qs(p.query)
        if parts == ["health"]: return self.send(200, {"ok": True})
        if parts == ["audit"]:
            if not self.auth("read_audit"): return
            return self.send(200, {"chain_valid": STORE.ledger.verify(), "entries": len(STORE.ledger.rows), "last": STORE.ledger.rows[-3:]})
        if len(parts) == 4 and parts[0] == "ingest" and parts[2] == "evidence-card":
            if not self.auth("read_evidence"): return
            try: card = I.evidence_card(parts[1], int(parts[3]))
            except ValueError: return self.send(400, {"error": "district code must be an integer"})
            return self.send(200 if card and "error" not in card else 404, card or {"error": "unknown upload"})
        if len(parts) == 3 and parts[0] == "districts" and parts[1] in DF.index:
            k = parts[1]
            if parts[2] == "indicators":
                if not self.auth("read_indicators", k): return
                r = DF.loc[k]; return self.send(200, {"district": k, "dgpi_implied": round(float(r.dgpi_per_1000), 2), "dgpi_census2011": round(float(r.dgpi_census), 2),
                    "rank_implied": int(r.rank_implied), "rank_census": int(r.rank_census), "cohort_note": "Yuva Nidhi 2022-23 cohort; registration signal, not unemployment"})
            if parts[2] == "gate":
                if not self.auth("read_routing", k): return
                return self.send(200, gate_for(k, q.get("scenario", ["real"])[0]))
        self.send(404, {"error": "not found"})
    def do_POST(self):
        if self.path.startswith("/ingest"):
            if not self.auth("ingest"): return
            n = int(self.headers.get("Content-Length", 0))
            if n > 20_000_000: return self.send(413, {"error": "file too large"})
            u, r, _ = self.who(); q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            res = I.ingest_csv(self.rfile.read(n), q.get("source", ["unnamed department feed"])[0], int(q.get("ref_year", ["2025"])[0]), u)
            STORE.ledger.record(u, r, "INGEST_" + ("ACCEPTED" if res["accepted"] else "REJECTED"), {k: res.get(k) for k in ("upload_id", "stage", "reason")})
            return self.send(201 if res["accepted"] else 422, res)
        if self.path != "/ledger": return self.send(404, {"error": "not found"})
        n = int(self.headers.get("Content-Length", 0)); body = json.loads(self.rfile.read(n) or b"{}")
        k = body.get("district")
        if k not in DF.index: return self.send(400, {"error": "unknown district"})
        if not self.auth("decide", k): return
        u, r, _ = self.who(); g = gate_for(k, body.get("scenario", "real"))
        try: STORE.ledger.human_decision(g, u, r, body.get("decision", ""), body.get("note", ""))
        except PermissionError as e: return self.send(409, {"error": "gate_blocked", "detail": str(e), "gate": g})
        except ValueError as e: return self.send(400, {"error": str(e)})
        self.send(201, {"logged": True, "gate_status": g["status"], "chain_valid": STORE.ledger.verify()})

class Srv(http.server.ThreadingHTTPServer):
    request_queue_size = 256; daemon_threads = True   # default backlog of 5 refused bursts of concurrent clients

def serve(port=0):
    srv = Srv(("127.0.0.1", port), H); threading.Thread(target=srv.serve_forever, daemon=True).start(); return srv
if __name__ == "__main__":
    s = serve(8000); print("Kaushal Radar API on http://127.0.0.1:8000 (Ctrl-C to stop)"); threading.Event().wait()
