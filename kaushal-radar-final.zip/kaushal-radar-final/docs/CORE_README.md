# Kaushal Radar: evidence pack (finale prototype)

Everything here runs on a plain laptop with Python 3, pandas, numpy and `cryptography` (security tests also need `openssl`).
Nothing here is a government deployment. Status is stated per file.

| File | What it is | Status |
|---|---|---|
| indicators_v2.csv | DGPI indicators for 31 districts (DES Karnataka tables) + Census 2011 denominator | real data |
| analysis_denominators_and_ai_tests.py | Denominator re-rank, income correlation, anomaly injection test | real data, reproducible |
| decision_engine.py, test_engine.py | Corroboration Gate, rank stability, hash-chained ledger (11 tests) | gate evidence cards are MOCK except Yuva Nidhi |
| pipeline.py, test_pipeline.py | Validate, dedupe, LGD re-coding, atomic publish (10 tests) | synthetic test data |
| bench_pipeline.py, benchmark_log.txt | 10K to 1M rows; failure injection mid-write | synthetic, 1 CPU, in memory |
| security.py, test_security.py, access_control.csv | Role access, audit chain, small-cell suppression, encryption, TLS (7 tests) | prototype; not independently reviewed |
| api_server.py, test_api.py, demo_flow.py, api_demo_transcript.txt | Local API: indicators, gate, ledger, audit (10 tests) | local prototype; header-stub auth |
| ai_eval.py, ai_eval_cases.csv, ai_eval_log.txt | 100-case evaluation of the brief checker | one drafting pass; numeric/entity/direction checks |
| llm_brief_test.py | The 31 LLM-drafted briefs | |
| Kaushal_Radar_Dashboard.html | Six-view dashboard prototype | real data; ledger is browser-local |
| claims_register.csv | Every slide number: source, calculation, limitation | |
| kaushal_radar_openapi_v0.1.yaml, data_contract_v0.1.yaml | Draft spec and contract | proposed, not deployed |

Run all tests: `python test_engine.py && python test_pipeline.py && python test_security.py && python test_api.py` (38 tests).
Demo the API flow: `python demo_flow.py`. Serve it: `python api_server.py`.

Known limits: registrations measure one cohort's scheme take-up, not unemployment. The 100-case evaluation tests a checker, not a trained model.
Four injected rank errors were missed because the wrong number matched another allowed number. Two genuine drafts were rejected for stale simulation percentages and one for a checker error on a mixed income/DGPI sentence.
