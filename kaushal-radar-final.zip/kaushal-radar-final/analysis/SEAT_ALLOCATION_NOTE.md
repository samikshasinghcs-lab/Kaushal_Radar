# Seat-allocation comparison (descriptive, 10,000 hypothetical seats)
No outcome data exists in this repo, so this shows how allocation rules DIFFER, not which one works.

| Rule | Kalyana-Karnataka seats (share) | Bengaluru Urban | Top-8 DGPI districts |
|---|---|---|---|
| Uniform (322 each) | 2,258 (22.6%) | 323 | 2,581 |
| Proportional to registrants | 2,786 (27.9%) | 657 | 3,654 |
| Proportional to registrants above the state rate | 5,017 (50.2%) | 0 | 7,296 |

Context: Kalyana-Karnataka has 27.9% of registrants and 19.4% of residents (implied). Registration is take-up of one scheme, not unemployment.
Routing then decides WHAT is checked first: of the top 8, 4 are supply-first (Raichur, Kalaburagi, Yadgir, Vijayapura) and 4 outcome-first (Bagalkote, Davanagere, Bidar, Shivamogga), threshold = state median MSME jobs per 1,000 (317, a pilot setting).
Files: routing_31_districts.csv, routing_scatter.png
