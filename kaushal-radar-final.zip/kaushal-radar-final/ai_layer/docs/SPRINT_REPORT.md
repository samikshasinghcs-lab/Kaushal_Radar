# Sprint report (Sprints 1-8 compressed into one build run)

> Executed in a sandbox with no network and no credentials. Everything below was actually run; numbers come from `python -m tools.run_all`.

| # | Sprint | Result |
|---|---|---|
| 1 | Provider, config, prompts, schemas | Mock provider + Anthropic adapter (injected-transport tests only), versioned prompts, strict validator. **Live adapter untested.** |
| 2 | Retrieval, context builder, evidence analyst | Authorisation-first retrieval, minimal contexts, evidence IDs cited and checked. |
| 3 | Contradiction / anomaly / uncertainty | Deterministic detection + explainers; all pass guards. |
| 4 | Policy brief + NLQ | Structured brief; NLQ yields allow-listed query object only. |
| 5 | Grounding, numeric, hallucination guards | Fabricated/unauthorised sources, wrong numbers/units, causal overreach all rejected. |
| 6 | Privacy, injection, logging, access control | Adversarial tests pass; **2 hard injection cases still evade the heuristic** (reported, not hidden). |
| 7 | 141-case evaluation lab | 139/141 behave as labelled; failures listed in `docs/EVALUATION_REPORT.md`. |
| 8 | Integration | API (stdlib HTTP) + static dashboards + demo journey; 13-step Raichur scenario test passes. |

1. **Files created:** everything in this bundle (new; no existing repo file was inspected or modified).
2. **Files modified:** none.
3. **Features:** all 38 components implemented (see `docs/COMPONENTS.md`).
4. **Tests executed:** 116 (unit, integration, security, failure-mode, API incl. real localhost HTTP, e2e, evaluation).
5. **Passed / failed:** 116 passed, 0 failed. Evaluation lab: 139/141 cases as labelled, 2 failed (both `difficulty: hard` injection cases).
6. **Known defects:** see `INTEGRATION_NOTES.md` section 3 (injection evasion; prompt 1.1.0 regresses 15 cases; live adapter untested; mock != LLM).
7. **Integration status:** self-contained. NOT yet wired to the repo's DGPI, decision_engine.py, access_control.csv, evidence tables or audit system.
8. **Remaining work:** wire the 6 adapter points; run the evaluation lab against a real provider; improve injection detection; human review of language quality; deploy behind TLS/gateway.

## Defects the test-suite itself found while building (all fixed)
- Mock analysts emitted numbers without citing their refs -> source-grounding guard rejected them.
- Denominator-gap percentage was not registered as a deterministic reference -> numeric guard rejected it (and showed my other cases passed only by coincidence).
- Evaluator measured numeric errors but did not fail cases on them -> fixed; mutation test now proves a self-consistent bug is caught.
- Evaluator "allowed evidence" list omitted secondary records -> inflated unsupported-claim rate (14.8% -> 0%).
