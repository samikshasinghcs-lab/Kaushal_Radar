# Kaushal Radar - AI decision-support layer

An officer asks *"Why is Raichur flagged?"*. The system authenticates the officer, checks district access, retrieves only
authorised evidence, calculates indicators with **deterministic code**, lets an AI layer *interpret* the findings, then
validates every claim, source and number before producing a brief that **always requires human review**.

```
Officer -> API -> authN + RBAC -> request validation -> injection/PII checks -> evidence retrieval (authorised only)
 -> deterministic engine (indicators, contradictions, anomalies, freshness, denominators) -> context builder (minimal)
 -> AI analysts (advisory) -> source grounding -> numeric integrity -> hallucination guard -> output safety
 -> decision gate (AI cannot override) -> human review -> hash-chained audit ledger
```

## Run it
```
python -m tools.run_all                # tests + evaluation lab + demo + component registry
python -m unittest discover -s tests -t .
python -m evaluation.runner            # writes evaluation/results.json, docs/EVALUATION_REPORT.md, dashboard/eval_dashboard.html
python -m demo.run_demo                # officer journey -> dashboard/demo_brief_raichur.html
```
No third-party packages, no network, no API key needed (deterministic mock provider by default).

## Hard rules enforced in code
- Role/identity come only from the bearer token via the server-side directory; any `role`/`user`/`districts` request parameter is rejected.
- AI never calculates indicators, sets/overrides the decision status, approves funding or records a human decision.
- Every fact/interpretation must cite existing, **authorised** evidence; every number must match a deterministic value.
- Failed validation => AI text withheld and `presentable_as_verified = false`. Provider failure => `FAILED_PROVIDER` (HTTP 503), never a silent success.
- "Automated checks passed" is NOT human verification; every brief is `human_review: PENDING`.

## Data honesty
All demo and evaluation data is **SYNTHETIC** (seeded generator; banner shown on every brief). The indicator set and flag rule
(`graduate_to_vacancy_ratio >= 1.5 x peer median`) are a *demonstration rule*, **not** the official DGPI.
See `INTEGRATION_NOTES.md` for plugging in the real DGPI, evidence source, identity source and audit system.
