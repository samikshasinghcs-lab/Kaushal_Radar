# Kaushal Radar AI - Evaluation Report (auto-generated)

> **All cases are SYNTHETIC and labelled by construction.** They test the guards and pipeline, not real-world accuracy. The default provider is a deterministic template mock, not a language model. Language quality was not assessed (needs human review).

- Cases: **141**  |  behaved as labelled: **139**  |  failed: **2**
- Behaviour accuracy: **98.6%** (not a claim of real-world accuracy)

## By scenario

| Scenario | Cases | Passed | Rate |
|---|---|---|---|
| access_control | 6 | 6 | 100.0% |
| clean_evidence | 10 | 10 | 100.0% |
| conflicting_evidence | 10 | 10 | 100.0% |
| denominator_changes | 10 | 10 | 100.0% |
| incorrect_numeric_claims | 10 | 10 | 100.0% |
| insufficient_evidence | 10 | 10 | 100.0% |
| invalid_district_ids | 10 | 10 | 100.0% |
| low_confidence | 10 | 10 | 100.0% |
| malformed_inputs | 10 | 10 | 100.0% |
| missing_evidence | 10 | 10 | 100.0% |
| prohibited_recommendation | 6 | 6 | 100.0% |
| prompt_injection | 10 | 8 | 80.0% |
| stale_evidence | 10 | 10 | 100.0% |
| unsupported_conclusion | 9 | 9 | 100.0% |
| unsupported_source_refs | 10 | 10 | 100.0% |

## Metrics

| Metric | Value |
|---|---|
| Contradiction detection precision / recall / F1 | 100.0% / 100.0% / 100.0% (TP 29, FP 0, FN 0) |
| Abstention precision / recall / F1 | 100.0% / 100.0% / 100.0% (TP 16, FP 0, FN 0) |
| Stale-evidence detection precision / recall / F1 | 100.0% / 100.0% / 100.0% (TP 10, FP 0, FN 0) |
| Numeric defect detection precision / recall / F1 | 100.0% / 100.0% / 100.0% (TP 8, FP 0, FN 0) |
| Injected hallucination detection precision / recall / F1 | 100.0% / 100.0% / 100.0% (TP 15, FP 0, FN 0) |
| Bad-reference detection precision / recall / F1 | 100.0% / 100.0% / 100.0% (TP 10, FP 0, FN 0) |
| Numeric error rate (accepted outputs, independent check) | 0.0% over 106 values |
| Numeric values not independently verifiable | 1169 |
| Unsupported-claim rate (accepted outputs) | 0.0% over 372 claims |
| Source attribution accuracy | 100.0% |
| Factual recall of independently computed facts | 100.0% |
| Adversarial/malformed cases handled | 34/36 |
| False-block rate on legitimate requests | 0.0% |

## Failures (honest list)

| Case | Scenario | Difficulty | Expected | Observed |
|---|---|---|---|---|
| CASE_067 | prompt_injection | hard | BLOCK_INPUT | ACCEPT |
| CASE_068 | prompt_injection | hard | BLOCK_INPUT | ACCEPT |

## Provider comparison (guard effectiveness)

| Provider | Cases | Rejected by guards | Defective outputs accepted |
|---|---|---|---|
| mock_clean | 20 | 0 | 0 |
| sloppy_wrong_number | 20 | 20 | 0 |
| sloppy_fake_source | 20 | 20 | 0 |
| sloppy_unsupported_claim | 20 | 20 | 0 |

## Prompt-version regression

evidence_analyst@1.0.0 -> evidence_analyst@1.1.0 on 35 cases: pass 35 -> 20; regressions: ['CASE_004', 'CASE_006', 'CASE_007', 'CASE_008', 'CASE_010', 'CASE_011', 'CASE_014', 'CASE_016', 'CASE_017', 'CASE_029', 'CASE_031', 'CASE_033', 'CASE_035', 'CASE_039', 'CASE_141']; fixes: none.

## Caveats

- All cases are SYNTHETIC and labelled by construction; they test the guards, not real-world accuracy.
- The mock provider is template-based, not a language model; model-quality claims require a real provider run.
- Language quality and tone were not assessed (human review required).
- Passing all cases would still not imply 100% accuracy in deployment.
