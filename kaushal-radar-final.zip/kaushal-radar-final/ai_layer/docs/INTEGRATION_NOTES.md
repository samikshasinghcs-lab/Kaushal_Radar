# Integration notes (read before copying into the repository)

I could not see the contents of your existing `ai/`, `security/`, `evaluation/`, `api/`, `dashboard/`, `decision_engine.py`,
`pipeline.py` or `access_control.csv`, so this bundle is **self-contained and does not import any existing repo module**.

## 1. Copy safely
1. Create a branch: `git checkout -b ai-layer-v1`.
2. After extracting this bundle, run `python tools/check_collisions.py /path/to/your/repo`. Every `CLASH` line is a file that
   already exists: **diff it, do not blindly overwrite**. Likely clashes: `__init__.py` files, `ai/provider.py`, `ai/config.py`,
   `ai/audit.py`, `security/access_control.py`, `evaluation/runner.py`, `tests/__init__.py`.
3. `security.py` vs `security/`: a package named `security/` shadows a module `security.py`. Keep your legacy module as `security_legacy.py`.
4. Run `python -m tools.run_all` from the repo root.

## 2. Adapter points (what is a stand-in today)
| Stand-in here | Replace with | Where |
|---|---|---|
| Demo flag rule + 5 demo indicators (`ai/deterministic.py`) | the real **DGPI** calculations | keep `build_bundle()` output shape; or compute DGPI there |
| `DecisionGate` builtin rules | your `decision_engine.py` | `DecisionGate(external_engine=fn)`; fn(bundle) -> `{"status","reason_codes"}` |
| `EvidenceStore` + synthetic data | your real evidence/provenance tables | build `EvidenceStore(records, sources)` from them; record schema in `ai/evidence_store.py::make_record` |
| `districts.py` positional IDs `KA-001..031` | your real district IDs | edit `DISTRICTS` |
| `UserDirectory` | your identity source / `access_control.csv` | implement `authenticate(token)->Identity`; keep roles/permissions in `ROLE_PERMISSIONS` |
| `AuditLedger` (local hash chain) | your audit system | subclass/forward `append()` |
| `MockProvider` | real LLM | `KR_PROVIDER=anthropic`, `ANTHROPIC_API_KEY`, `KR_MODEL`; then **run the evaluation lab with it** |

## 3. Known defects / limitations (not hidden)
- Prompt-injection detection is heuristic: 2 deliberately hard evaluation cases (paraphrase, Hinglish) **fail**.
- `evidence_analyst@1.1.0` regresses 15 evaluation cases (rounding beyond numeric tolerance): do **not** promote it.
- The real Anthropic adapter has only been tested with an injected transport, never live.
- Everything is validated against a deterministic template mock, not a language model; real-model quality is unmeasured.
- Component statuses in `component_registry.json` are computed from executed tests; 12 are capped at SECURITY_VERIFIED for the reasons above.
- No authentication rate-limiting/lockout, no TLS (put the API behind your gateway), in-process cache and ledger only.
