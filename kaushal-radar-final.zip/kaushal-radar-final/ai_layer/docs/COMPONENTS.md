# Components (auto-generated from tools/components_meta.py)

Status per component is in `component_registry.json` and is computed by executing tests.

## A. Core AI

### 1. evidence_analyst
- **Purpose:** Explains supporting signals with evidence IDs.
- **Files:** ai/mock_analysts.py, ai/prompts.py
- **Dependencies:** context_builder, provider
- **Limitations:** Default provider is a deterministic template mock, not a language model; real-LLM behaviour is unmeasured.
- **Tests:** unit tests.unit.test_analysts_standalone; integration tests.integration.test_pipeline_integration, tests.integration.test_e2e_raichur; security tests.security.test_pipeline_security

### 2. contradiction_analyst
- **Purpose:** Explains deterministic contradictions; separates GENUINE, MEASUREMENT_DIFFERENCE, CROSS_INDICATOR_TENSION.
- **Files:** ai/mock_analysts.py, ai/deterministic.py
- **Dependencies:** deterministic
- **Limitations:** Default provider is a deterministic template mock, not a language model; real-LLM behaviour is unmeasured. Detection rules are demonstration rules.
- **Tests:** unit tests.unit.test_analysts_standalone, tests.unit.test_deterministic; integration tests.integration.test_pipeline_integration, tests.integration.test_e2e_raichur; security tests.security.test_pipeline_security

### 3. anomaly_explainer
- **Purpose:** Explains only anomalies found by deterministic z-score tests.
- **Files:** ai/mock_analysts.py, ai/deterministic.py
- **Dependencies:** deterministic
- **Limitations:** Default provider is a deterministic template mock, not a language model; real-LLM behaviour is unmeasured.
- **Tests:** unit tests.unit.test_analysts_standalone, tests.unit.test_deterministic; integration tests.integration.test_pipeline_integration, tests.integration.test_e2e_raichur; security tests.security.test_pipeline_security

### 4. policy_brief
- **Purpose:** Assembles structured brief; suggests investigations, never actions.
- **Files:** ai/policy_brief.py, ai/mock_analysts.py
- **Dependencies:** all analysts, guards
- **Limitations:** Default provider is a deterministic template mock, not a language model; real-LLM behaviour is unmeasured.
- **Tests:** unit tests.unit.test_analysts_standalone; integration tests.integration.test_pipeline_integration, tests.integration.test_e2e_raichur; security tests.security.test_pipeline_security

### 5. natural_language_query
- **Purpose:** Maps questions to an allow-listed intent+district object; never runs generated SQL/Python.
- **Files:** ai/natural_language_query.py
- **Dependencies:** districts, schemas
- **Limitations:** Keyword intent matching; one district per query; English only.
- **Tests:** unit tests.unit.test_nlq; integration tests.integration.test_pipeline_integration, tests.integration.test_e2e_raichur; security tests.security.test_security_components, tests.security.test_pipeline_security

### 6. source_grounding_engine
- **Purpose:** Checks every claim cites existing AUTHORISED evidence; flags unknown IDs in text.
- **Files:** ai/source_grounding.py
- **Dependencies:** deterministic bundle
- **Limitations:** Checks references, not semantic entailment of the claim text.
- **Tests:** unit tests.unit.test_guards; integration tests.integration.test_pipeline_integration, tests.integration.test_e2e_raichur; security tests.security.test_pipeline_security

### 7. uncertainty_explainer
- **Purpose:** Explains missing/stale data, denominator sensitivity, ranking instability.
- **Files:** ai/mock_analysts.py, ai/deterministic.py
- **Dependencies:** deterministic
- **Limitations:** Default provider is a deterministic template mock, not a language model; real-LLM behaviour is unmeasured.
- **Tests:** unit tests.unit.test_analysts_standalone, tests.unit.test_deterministic; integration tests.integration.test_pipeline_integration, tests.integration.test_e2e_raichur; security tests.security.test_pipeline_security

### 8. recommendation_explainer
- **Purpose:** Explains the gate's status/reason codes; guard rejects any other status.
- **Files:** ai/mock_analysts.py, ai/decision_gate.py
- **Dependencies:** decision_gate
- **Limitations:** Default provider is a deterministic template mock, not a language model; real-LLM behaviour is unmeasured.
- **Tests:** unit tests.unit.test_analysts_standalone, tests.unit.test_privacy_abstention_audit_cache_gate; integration tests.integration.test_pipeline_integration, tests.integration.test_e2e_raichur; security tests.security.test_pipeline_security

## B. Infrastructure

### 9. provider_manager
- **Purpose:** Provider selection, offline mock, real Anthropic adapter, rate limiter, JSON+schema enforcement.
- **Files:** ai/provider.py, ai/config.py
- **Dependencies:** retry, schemas
- **Limitations:** REAL ADAPTER NEVER CALLED LIVE in this repo's tests (no credentials/network): verified only with an injected transport.
- **Tests:** unit tests.unit.test_schemas_prompts_provider; integration tests.integration.test_pipeline_integration, tests.integration.test_failure_modes; security tests.security.test_pipeline_security

### 10. prompt_manager
- **Purpose:** Versioned prompts; version recorded on every call and in the audit log.
- **Files:** ai/prompts.py
- **Dependencies:** -
- **Limitations:** Prompt text is untested against a real model.
- **Tests:** unit tests.unit.test_schemas_prompts_provider; integration tests.integration.test_pipeline_integration, tests.integration.test_e2e_raichur; security tests.security.test_pipeline_security

### 11. output_validator
- **Purpose:** Strict JSON-schema validation; malformed output rejected and retried then fails closed.
- **Files:** ai/schemas.py
- **Dependencies:** -
- **Limitations:** Own minimal validator (subset of JSON Schema).
- **Tests:** unit tests.unit.test_schemas_prompts_provider, tests.unit.test_guards; integration tests.integration.test_pipeline_integration, tests.integration.test_e2e_raichur; security tests.security.test_pipeline_security

### 12. evidence_retrieval
- **Purpose:** Authorisation-first retrieval; excludes restricted, invalid, unregistered, injected records.
- **Files:** ai/retrieval.py
- **Dependencies:** access_control, prompt_injection
- **Limitations:** In-memory store; swap for the repo's real evidence source.
- **Tests:** unit tests.unit.test_retrieval_context_minimisation; integration tests.integration.test_pipeline_integration, tests.integration.test_e2e_raichur; security tests.security.test_pipeline_security

### 13. context_builder
- **Purpose:** Minimal per-task context with source metadata; privacy-checked.
- **Files:** ai/context_builder.py
- **Dependencies:** data_minimisation, privacy
- **Limitations:** -
- **Tests:** unit tests.unit.test_retrieval_context_minimisation; integration tests.integration.test_pipeline_integration, tests.integration.test_e2e_raichur; security tests.security.test_pipeline_security

### 14. hallucination_guard
- **Purpose:** Flags causal overreach, invented contradictions/anomalies/staleness, out-of-scope districts, status mismatches, inflated confidence.
- **Files:** ai/hallucination_guard.py
- **Dependencies:** deterministic bundle
- **Limitations:** Regex/rule based; novel phrasing can evade it.
- **Tests:** unit tests.unit.test_guards; integration tests.integration.test_pipeline_integration, tests.integration.test_e2e_raichur; security tests.security.test_pipeline_security

### 15. numeric_integrity_guard
- **Purpose:** Every declared and in-text number must match deterministic values (tolerance 0.5%).
- **Files:** ai/numeric_guard.py
- **Dependencies:** deterministic bundle
- **Limitations:** A wrong number that equals another legitimate value is only caught via declared refs.
- **Tests:** unit tests.unit.test_guards; integration tests.integration.test_pipeline_integration, tests.integration.test_e2e_raichur; security tests.security.test_pipeline_security

### 16. privacy_layer
- **Purpose:** Detects/blocks Aadhaar (Verhoeff), PAN, phone, email, blocked field names before model submission.
- **Files:** ai/privacy.py
- **Dependencies:** -
- **Limitations:** Pattern based; misses names/addresses in free text.
- **Tests:** unit tests.unit.test_privacy_abstention_audit_cache_gate; integration tests.integration.test_pipeline_integration, tests.integration.test_e2e_raichur; security tests.security.test_pipeline_security

### 17. abstention_layer
- **Purpose:** Explicit insufficient-evidence response with reason codes; no AI call.
- **Files:** ai/abstention.py
- **Dependencies:** deterministic
- **Limitations:** Thresholds are configuration defaults.
- **Tests:** unit tests.unit.test_privacy_abstention_audit_cache_gate; integration tests.integration.test_pipeline_integration, tests.integration.test_e2e_raichur; security tests.security.test_pipeline_security

### 18. ai_logging
- **Purpose:** Request ID, model, prompt versions, evidence IDs, validation outcome, timestamp.
- **Files:** ai/audit.py
- **Dependencies:** -
- **Limitations:** -
- **Tests:** unit tests.unit.test_privacy_abstention_audit_cache_gate; integration tests.integration.test_pipeline_integration, tests.integration.test_e2e_raichur; security tests.security.test_pipeline_security

### 19. retry_manager
- **Purpose:** Bounded exponential backoff; fatal errors not retried; exhaustion raises.
- **Files:** ai/retry.py
- **Dependencies:** -
- **Limitations:** -
- **Tests:** unit tests.unit.test_retry; integration tests.integration.test_failure_modes; security tests.security.test_pipeline_security

### 20. response_cache
- **Purpose:** Caches only validated OK responses; key binds to role/district scope, versions, evidence fingerprint.
- **Files:** ai/cache.py
- **Dependencies:** -
- **Limitations:** In-process only.
- **Tests:** unit tests.unit.test_privacy_abstention_audit_cache_gate; integration tests.integration.test_pipeline_integration, tests.integration.test_e2e_raichur; security tests.security.test_pipeline_security

## C. Evaluation

### 21. dataset_generator
- **Purpose:** 141 seeded SYNTHETIC cases with construction labels and independent arithmetic.
- **Files:** evaluation/generate_cases.py, evaluation/dataset.jsonl
- **Dependencies:** -
- **Limitations:** Labels reflect how cases were built; not real-world ground truth.
- **Tests:** unit tests.evaluation.test_evaluation_lab; integration tests.evaluation.test_evaluation_lab; security tests.evaluation.test_evaluation_lab

### 22. factual_accuracy
- **Purpose:** Recall of independently computed facts in accepted outputs.
- **Files:** evaluation/factual_accuracy.py
- **Dependencies:** harness
- **Limitations:** Does not assess language quality.
- **Tests:** unit tests.evaluation.test_evaluation_lab; integration tests.evaluation.test_evaluation_lab; security tests.evaluation.test_evaluation_lab

### 23. numeric_accuracy
- **Purpose:** Numeric error rate vs independent values; numeric-defect detection.
- **Files:** evaluation/numeric_accuracy.py
- **Dependencies:** harness
- **Limitations:** Many values (counts, z-scores) are not independently verifiable and are reported as such.
- **Tests:** unit tests.evaluation.test_evaluation_lab; integration tests.evaluation.test_evaluation_lab; security tests.evaluation.test_evaluation_lab

### 24. hallucination_evaluation
- **Purpose:** Unsupported-claim rate and injected-hallucination detection.
- **Files:** evaluation/hallucination.py
- **Dependencies:** harness
- **Limitations:** -
- **Tests:** unit tests.evaluation.test_evaluation_lab; integration tests.evaluation.test_evaluation_lab; security tests.evaluation.test_evaluation_lab

### 25. source_attribution
- **Purpose:** Attribution accuracy and bad-reference detection.
- **Files:** evaluation/source_grounding.py
- **Dependencies:** harness
- **Limitations:** -
- **Tests:** unit tests.evaluation.test_evaluation_lab; integration tests.evaluation.test_evaluation_lab; security tests.evaluation.test_evaluation_lab

### 26. contradiction_evaluation
- **Purpose:** Precision/recall/F1 for labelled conflicts.
- **Files:** evaluation/runner.py
- **Dependencies:** harness
- **Limitations:** -
- **Tests:** unit tests.evaluation.test_evaluation_lab; integration tests.evaluation.test_evaluation_lab; security tests.evaluation.test_evaluation_lab

### 27. missing_data_evaluation
- **Purpose:** Missing required/optional evidence cases.
- **Files:** evaluation/harness.py
- **Dependencies:** harness
- **Limitations:** -
- **Tests:** unit tests.evaluation.test_evaluation_lab; integration tests.evaluation.test_evaluation_lab; security tests.evaluation.test_evaluation_lab

### 28. stale_data_evaluation
- **Purpose:** Stale primary/secondary evidence detection.
- **Files:** evaluation/runner.py
- **Dependencies:** harness
- **Limitations:** -
- **Tests:** unit tests.evaluation.test_evaluation_lab; integration tests.evaluation.test_evaluation_lab; security tests.evaluation.test_evaluation_lab

### 29. abstention_evaluation
- **Purpose:** Abstention precision/recall/F1.
- **Files:** evaluation/runner.py
- **Dependencies:** harness
- **Limitations:** -
- **Tests:** unit tests.evaluation.test_evaluation_lab; integration tests.evaluation.test_evaluation_lab; security tests.evaluation.test_evaluation_lab

### 30. robustness_evaluation
- **Purpose:** Malformed/adversarial/unauthorised input handling by difficulty; hard cases expose gaps.
- **Files:** evaluation/robustness.py
- **Dependencies:** harness
- **Limitations:** Two 'hard' injection cases currently FAIL by design of the heuristic detector.
- **Tests:** unit tests.evaluation.test_evaluation_lab; integration tests.evaluation.test_evaluation_lab; security tests.evaluation.test_evaluation_lab

### 31. regression_testing
- **Purpose:** Baseline, prompt-version and provider comparison; detects prompt 1.1.0 regression.
- **Files:** evaluation/regression.py
- **Dependencies:** harness
- **Limitations:** -
- **Tests:** unit tests.evaluation.test_evaluation_lab; integration tests.evaluation.test_evaluation_lab; security tests.evaluation.test_evaluation_lab

### 32. evaluation_dashboard
- **Purpose:** Static dashboard + markdown report rendered ONLY from results.json.
- **Files:** evaluation/report.py, dashboard/eval_dashboard.html
- **Dependencies:** runner
- **Limitations:** Static HTML; no live updates.
- **Tests:** unit tests.evaluation.test_evaluation_lab; integration tests.evaluation.test_evaluation_lab; security tests.evaluation.test_evaluation_lab

## D. Security

### 33. prompt_injection_defence
- **Purpose:** Heuristic detection on questions; quarantine of untrusted evidence text.
- **Files:** security/prompt_injection.py
- **Dependencies:** -
- **Limitations:** Paraphrased / non-English injections evade it (documented in tests and report).
- **Tests:** unit tests.security.test_security_components; integration tests.integration.test_pipeline_integration, tests.integration.test_e2e_raichur; security tests.security.test_security_components, tests.security.test_pipeline_security

### 34. input_sanitisation
- **Purpose:** Types, lengths, characters, district IDs, parameter allow-list, privilege-parameter rejection.
- **Files:** security/input_validation.py
- **Dependencies:** districts
- **Limitations:** -
- **Tests:** unit tests.security.test_security_components; integration tests.integration.test_pipeline_integration, tests.integration.test_e2e_raichur; security tests.security.test_security_components, tests.security.test_pipeline_security

### 35. output_safety
- **Purpose:** Rejects funding/action recommendations, review bypass, status override, absolute claims.
- **Files:** security/output_safety.py
- **Dependencies:** -
- **Limitations:** Regex based.
- **Tests:** unit tests.security.test_security_components; integration tests.integration.test_pipeline_integration, tests.integration.test_e2e_raichur; security tests.security.test_security_components, tests.security.test_pipeline_security

### 36. access_control
- **Purpose:** Token authentication separate from role/district authorisation; role never read from request.
- **Files:** security/access_control.py
- **Dependencies:** -
- **Limitations:** Reference UserDirectory; NOT yet wired to the repo's access_control.csv/identity source.
- **Tests:** unit tests.security.test_security_components; integration tests.integration.test_pipeline_integration, tests.integration.test_e2e_raichur; security tests.security.test_security_components, tests.security.test_pipeline_security

### 37. data_minimisation
- **Purpose:** Allow-listed evidence fields only; per-task minimal contexts.
- **Files:** security/data_minimisation.py
- **Dependencies:** -
- **Limitations:** -
- **Tests:** unit tests.unit.test_retrieval_context_minimisation; integration tests.integration.test_pipeline_integration, tests.integration.test_e2e_raichur; security tests.security.test_pipeline_security

### 38. audit_integration
- **Purpose:** Hash-chained ledger of AI requests, validation failures, denials, human reviews.
- **Files:** ai/audit.py, ai/master_pipeline.py
- **Dependencies:** -
- **Limitations:** Local ledger; NOT yet connected to the repo's own audit system.
- **Tests:** unit tests.unit.test_privacy_abstention_audit_cache_gate; integration tests.integration.test_pipeline_integration, tests.integration.test_e2e_raichur; security tests.security.test_pipeline_security
