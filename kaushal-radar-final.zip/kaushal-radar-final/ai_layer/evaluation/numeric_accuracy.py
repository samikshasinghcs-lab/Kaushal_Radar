"""Numeric accuracy: error rate in accepted outputs + detection of injected numeric defects."""
from .metrics_util import prf, rate


def compute(results):
    acc = [r["metrics"] for r in results if r["observed"] == "ACCEPT"]
    total = sum(m["numeric_total"] for m in acc)
    wrong = sum(m["numeric_wrong"] for m in acc)
    unv = sum(m["numeric_unverified"] for m in acc)
    num = [r for r in results if r["scenario"] == "incorrect_numeric_claims"]
    d = [r for r in num if r["defect"]]
    tol = [r for r in num if not r["defect"]]
    tp = sum(1 for r in d if r["observed"] == "REJECT_OUTPUT" and r["passed"])
    return {"numeric_values_checked_independently": total, "numeric_errors_in_accepted_outputs": wrong,
            "numeric_error_rate": rate(wrong, total), "numeric_values_not_independently_verified": unv,
            "defect_detection": prf(tp, sum(1 for r in tol if r["observed"] != "ACCEPT"), len(d) - tp),
            "tolerable_rounding_accepted": sum(1 for r in tol if r["observed"] == "ACCEPT"), "tolerable_rounding_cases": len(tol)}
