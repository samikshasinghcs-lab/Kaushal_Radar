"""Robustness: malicious/malformed/unauthorised input handling, split by difficulty."""
from .metrics_util import rate

SCEN = ("prompt_injection", "malformed_inputs", "invalid_district_ids", "access_control")


def compute(results):
    r = [x for x in results if x["scenario"] in SCEN]
    by = {}
    for x in r:
        d = by.setdefault(x["difficulty"], {"cases": 0, "passed": 0})
        d["cases"] += 1
        d["passed"] += int(x["passed"])
    clean = [x for x in results if x["expected"] == "ACCEPT"]
    return {"adversarial_cases": len(r), "handled_correctly": sum(x["passed"] for x in r),
            "handled_rate": rate(sum(x["passed"] for x in r), len(r)), "by_difficulty": by,
            "false_block_rate_on_legitimate": rate(sum(1 for x in clean if x["observed"] != "ACCEPT"), len(clean)),
            "note": "Injection detection is heuristic; 'hard' (paraphrased / non-English) cases are expected to expose gaps."}
