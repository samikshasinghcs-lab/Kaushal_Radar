"""Runs the full evaluation lab: python -m evaluation.runner [--save-baseline]"""
import json
import os
import sys
from collections import Counter

from . import factual_accuracy, hallucination, numeric_accuracy, regression, robustness, source_grounding
from .harness import load_dataset, run_case
from .metrics_util import prf, rate

HERE = os.path.dirname(os.path.abspath(__file__))
DATASET = os.path.join(HERE, "dataset.jsonl")


def run(dataset=DATASET, with_comparisons=True):
    cases = load_dataset(dataset)
    results = [run_case(c) for c in cases]
    by_s = {}
    for r in results:
        d = by_s.setdefault(r["scenario"], {"cases": 0, "passed": 0})
        d["cases"] += 1
        d["passed"] += int(r["passed"])
    for d in by_s.values():
        d["pass_rate"] = d["passed"] / d["cases"]
    contr = prf(sum(1 for c, r in zip(cases, results) if c["expected_contradictions"] and r["pred"]["contradiction"]),
                sum(1 for c, r in zip(cases, results) if not c["expected_contradictions"] and r["pred"]["contradiction"]),
                sum(1 for c, r in zip(cases, results) if c["expected_contradictions"] and not r["pred"]["contradiction"]))
    abst = prf(sum(1 for r in results if r["expected"] == "ABSTAIN" and r["observed"] == "ABSTAIN"),
               sum(1 for r in results if r["expected"] != "ABSTAIN" and r["observed"] == "ABSTAIN"),
               sum(1 for r in results if r["expected"] == "ABSTAIN" and r["observed"] != "ABSTAIN"))
    stale_pos = [c for c in cases if any(f["type"] == "stale_evidence" for f in c["expected_facts"])]
    stale = prf(sum(1 for c, r in zip(cases, results) if c in stale_pos and r["pred"]["stale"]),
                sum(1 for c, r in zip(cases, results) if c not in stale_pos and r["pred"]["stale"]
                    and not any(x["type"] == "stale_evidence" for x in c["expected_facts"]) and c["scenario"] != "low_confidence"),
                sum(1 for c, r in zip(cases, results) if c in stale_pos and not r["pred"]["stale"]))
    failures = [r for r in results if not r["passed"]]
    out = {
        "dataset": {"cases": len(cases), "label_origin": "SYNTHETIC_CONSTRUCTED", "by_scenario": dict(Counter(c["scenario"] for c in cases))},
        "overall": {"behaviour_accuracy": rate(sum(r["passed"] for r in results), len(results)), "passed": sum(r["passed"] for r in results),
                    "failed": len(failures), "reviewed_by_human": False},
        "by_scenario": by_s, "contradiction_detection": contr, "abstention": abst, "stale_detection": stale,
        "factual": factual_accuracy.compute(results), "numeric": numeric_accuracy.compute(results),
        "hallucination": hallucination.compute(results), "source_attribution": source_grounding.compute(results),
        "robustness": robustness.compute(results),
        "failure_categories": dict(Counter(f"{r['scenario']}: expected {r['expected']} got {r['observed']}" for r in failures)),
        "failures": [{k: r[k] for k in ("case_id", "scenario", "difficulty", "severity", "expected", "observed", "detail")} for r in failures],
        "results": results,
        "caveats": ["All cases are SYNTHETIC and labelled by construction; they test the guards, not real-world accuracy.",
                    "The mock provider is template-based, not a language model; model-quality claims require a real provider run.",
                    "Language quality and tone were not assessed (human review required).",
                    "Passing all cases would still not imply 100% accuracy in deployment."],
    }
    if with_comparisons:
        out["prompt_version_comparison"] = regression.prompt_version_comparison(cases)
        out["provider_comparison"] = regression.provider_comparison(cases)
        base = regression.load_baseline()
        out["baseline_comparison"] = regression.compare(base, results) if base else None
    return out


def main(argv=None):
    argv = argv if argv is not None else sys.argv[1:]
    from . import report
    res = run()
    with open(os.path.join(HERE, "results.json"), "w") as f:
        json.dump(res, f, indent=1, default=str)
    root = os.path.dirname(HERE)
    report.write_markdown(res, os.path.join(root, "docs", "EVALUATION_REPORT.md"))
    report.write_dashboard(res, os.path.join(root, "dashboard", "eval_dashboard.html"))
    if "--save-baseline" in argv:
        regression.save_baseline(res["results"])
    print(f"{res['overall']['passed']}/{res['dataset']['cases']} cases behaved as labelled; {res['overall']['failed']} failed")
    return res


if __name__ == "__main__":
    main()
