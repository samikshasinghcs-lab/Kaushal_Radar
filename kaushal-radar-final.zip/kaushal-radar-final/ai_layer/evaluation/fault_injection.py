"""Evaluation-only providers that inject known defects. Never imported by production code paths."""
import json

from ai.exceptions import ProviderTimeout
from ai.mock_analysts import fmt, generate
from ai.provider import MockProvider, ProviderResponse


def apply_mutation(out, m):
    claims = out["claims"]
    op = m["op"]
    ci = m.get("claim_index", 0)
    if op in ("set_number", "scale_number"):
        n = claims[ci]["numbers"][m.get("number_index", 0)]
        old = n["value"]
        new = m["value"] if op == "set_number" else old * m["factor"]
        n["value"] = new
        claims[ci]["text"] = claims[ci]["text"].replace(fmt(old), fmt(new), 1)
    elif op == "set_unit":
        claims[ci]["numbers"][m.get("number_index", 0)]["unit"] = m["unit"]
    elif op == "append_text":
        claims[ci]["text"] += " " + m["text"]
    elif op == "set_text":
        claims[ci]["text"] = m["text"]
    elif op == "replace_evidence":
        claims[ci]["evidence_ids"][0] = m["to"]
    elif op == "add_indicator_ref":
        claims[ci]["indicator_ids"].append(m["ref"])
    elif op == "add_evidence_ref":
        claims[ci]["evidence_ids"].append(m["ref"])
    elif op == "clear_refs":
        claims[ci].update(evidence_ids=[], indicator_ids=[], numbers=[])
    elif op == "add_claim":
        c = dict(m["claim"])
        c.setdefault("numbers", [])
        c.setdefault("indicator_ids", [])
        claims.append(c)
    elif op == "set_confidence":
        out["confidence"] = m["value"]
    elif op == "drop_key":
        out.pop(m["key"], None)
    else:
        raise ValueError(f"unknown mutation op {op}")
    return out


class MutatingProvider(MockProvider):
    """Deterministic mock output + labelled defects. `raw_text` replaces the whole response."""
    name = "mutating_mock"

    def __init__(self, mutations, model="mock-deterministic-1"):
        super().__init__(model)
        self.mutations = mutations

    def complete(self, *, task, system, prompt, context, prompt_version):
        out = generate(task, context, prompt_version)
        for m in self.mutations:
            if m.get("task") != task:
                continue
            if m["op"] == "raw_text":
                return ProviderResponse(m["text"], self.model)
            apply_mutation(out, m)
        return ProviderResponse(json.dumps(out, sort_keys=True), self.model)


SLOPPY_MODES = {
    "sloppy_wrong_number": [{"task": "evidence_analyst", "op": "scale_number", "factor": 1.37, "number_index": 2}],
    "sloppy_fake_source": [{"task": "evidence_analyst", "op": "add_evidence_ref", "ref": "EV_999_FABRICATED"}],
    "sloppy_unsupported_claim": [{"task": "evidence_analyst", "op": "add_claim", "claim": {
        "claim_id": "EA_X", "kind": "fact", "text": "Employers are avoiding the district because of poor infrastructure.",
        "evidence_ids": [], "indicator_ids": ["IND_GVR"]}}],
}


class FlakyProvider(MockProvider):
    """Fails with the given exceptions first, then behaves like the mock (for retry/outage tests)."""
    name = "flaky_mock"

    def __init__(self, failures):
        super().__init__()
        self.failures, self.calls = list(failures), 0

    def complete(self, **kw):
        self.calls += 1
        if self.failures:
            raise self.failures.pop(0)
        return super().complete(**kw)


class AlwaysFailProvider(MockProvider):
    name = "down"

    def __init__(self, exc_factory=lambda: ProviderTimeout("timeout")):
        super().__init__()
        self.exc_factory, self.calls = exc_factory, 0

    def complete(self, **kw):
        self.calls += 1
        raise self.exc_factory()
