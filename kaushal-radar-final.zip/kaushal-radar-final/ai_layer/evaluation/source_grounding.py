"""Source attribution: correct citations on accepted outputs + detection of fabricated/unauthorised refs."""
from .metrics_util import prf, rate


def compute(results):
    acc = [r["metrics"] for r in results if r["observed"] == "ACCEPT" and r["metrics"]["sources_expected"]]
    exp, found = sum(m["sources_expected"] for m in acc), sum(m["sources_found"] for m in acc)
    s = [r for r in results if r["scenario"] == "unsupported_source_refs"]
    tp = sum(1 for r in s if r["observed"] == "REJECT_OUTPUT" and r["passed"])
    return {"source_attribution_accuracy": rate(found, exp), "expected_sources": exp, "sources_cited": found,
            "bad_reference_detection": prf(tp, 0, len(s) - tp), "bad_reference_cases": len(s)}
