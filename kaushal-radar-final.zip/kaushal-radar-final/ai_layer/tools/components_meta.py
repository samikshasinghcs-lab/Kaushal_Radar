"""Single source of truth for the 38 components (used by the registry builder and docs/COMPONENTS.md)."""
U = {"analysts": "tests.unit.test_analysts_standalone", "det": "tests.unit.test_deterministic", "guards": "tests.unit.test_guards",
     "nlq": "tests.unit.test_nlq", "misc": "tests.unit.test_privacy_abstention_audit_cache_gate",
     "retr": "tests.unit.test_retrieval_context_minimisation", "retry": "tests.unit.test_retry",
     "prov": "tests.unit.test_schemas_prompts_provider"}
I = {"pipe": "tests.integration.test_pipeline_integration", "fail": "tests.integration.test_failure_modes",
     "api": "tests.integration.test_api", "e2e": "tests.integration.test_e2e_raichur"}
S = {"comp": "tests.security.test_security_components", "pipe": "tests.security.test_pipeline_security"}
E = "tests.evaluation.test_evaluation_lab"
DEFAULT_INT = [I["pipe"], I["e2e"]]


def c(n, key, group, files, purpose, depends, limits, unit, integ=None, sec=None, fail=None, demo="pipeline", cap=None):
    return dict(n=n, key=key, group=group, files=files, purpose=purpose, depends=depends, limitations=limits, unit=unit,
                integration=integ or DEFAULT_INT, security=sec or [S["pipe"]], failure=fail or unit, demo=demo, cap=cap)


MOCK = "Default provider is a deterministic template mock, not a language model; real-LLM behaviour is unmeasured."
COMPONENTS = [
    c(1, "evidence_analyst", "A. Core AI", ["ai/mock_analysts.py", "ai/prompts.py"], "Explains supporting signals with evidence IDs.", "context_builder, provider", MOCK, [U["analysts"]], fail=[U["analysts"], U["guards"]]),
    c(2, "contradiction_analyst", "A. Core AI", ["ai/mock_analysts.py", "ai/deterministic.py"], "Explains deterministic contradictions; separates GENUINE, MEASUREMENT_DIFFERENCE, CROSS_INDICATOR_TENSION.", "deterministic", MOCK + " Detection rules are demonstration rules.", [U["analysts"], U["det"]]),
    c(3, "anomaly_explainer", "A. Core AI", ["ai/mock_analysts.py", "ai/deterministic.py"], "Explains only anomalies found by deterministic z-score tests.", "deterministic", MOCK, [U["analysts"], U["det"]]),
    c(4, "policy_brief", "A. Core AI", ["ai/policy_brief.py", "ai/mock_analysts.py"], "Assembles structured brief; suggests investigations, never actions.", "all analysts, guards", MOCK, [U["analysts"]]),
    c(5, "natural_language_query", "A. Core AI", ["ai/natural_language_query.py"], "Maps questions to an allow-listed intent+district object; never runs generated SQL/Python.", "districts, schemas", "Keyword intent matching; one district per query; English only.", [U["nlq"]], sec=[S["comp"], S["pipe"]]),
    c(6, "source_grounding_engine", "A. Core AI", ["ai/source_grounding.py"], "Checks every claim cites existing AUTHORISED evidence; flags unknown IDs in text.", "deterministic bundle", "Checks references, not semantic entailment of the claim text.", [U["guards"]]),
    c(7, "uncertainty_explainer", "A. Core AI", ["ai/mock_analysts.py", "ai/deterministic.py"], "Explains missing/stale data, denominator sensitivity, ranking instability.", "deterministic", MOCK, [U["analysts"], U["det"]]),
    c(8, "recommendation_explainer", "A. Core AI", ["ai/mock_analysts.py", "ai/decision_gate.py"], "Explains the gate's status/reason codes; guard rejects any other status.", "decision_gate", MOCK, [U["analysts"], U["misc"]]),
    c(9, "provider_manager", "B. Infrastructure", ["ai/provider.py", "ai/config.py"], "Provider selection, offline mock, real Anthropic adapter, rate limiter, JSON+schema enforcement.", "retry, schemas", "REAL ADAPTER NEVER CALLED LIVE in this repo's tests (no credentials/network): verified only with an injected transport.", [U["prov"]], integ=[I["pipe"], I["fail"]], fail=[U["prov"], I["fail"]], cap="SECURITY_VERIFIED"),
    c(10, "prompt_manager", "B. Infrastructure", ["ai/prompts.py"], "Versioned prompts; version recorded on every call and in the audit log.", "-", "Prompt text is untested against a real model.", [U["prov"]]),
    c(11, "output_validator", "B. Infrastructure", ["ai/schemas.py"], "Strict JSON-schema validation; malformed output rejected and retried then fails closed.", "-", "Own minimal validator (subset of JSON Schema).", [U["prov"], U["guards"]], fail=[U["prov"], I["fail"]]),
    c(12, "evidence_retrieval", "B. Infrastructure", ["ai/retrieval.py"], "Authorisation-first retrieval; excludes restricted, invalid, unregistered, injected records.", "access_control, prompt_injection", "In-memory store; swap for the repo's real evidence source.", [U["retr"]]),
    c(13, "context_builder", "B. Infrastructure", ["ai/context_builder.py"], "Minimal per-task context with source metadata; privacy-checked.", "data_minimisation, privacy", "-", [U["retr"]]),
    c(14, "hallucination_guard", "B. Infrastructure", ["ai/hallucination_guard.py"], "Flags causal overreach, invented contradictions/anomalies/staleness, out-of-scope districts, status mismatches, inflated confidence.", "deterministic bundle", "Regex/rule based; novel phrasing can evade it.", [U["guards"]]),
    c(15, "numeric_integrity_guard", "B. Infrastructure", ["ai/numeric_guard.py"], "Every declared and in-text number must match deterministic values (tolerance 0.5%).", "deterministic bundle", "A wrong number that equals another legitimate value is only caught via declared refs.", [U["guards"]]),
    c(16, "privacy_layer", "B. Infrastructure", ["ai/privacy.py"], "Detects/blocks Aadhaar (Verhoeff), PAN, phone, email, blocked field names before model submission.", "-", "Pattern based; misses names/addresses in free text.", [U["misc"]], sec=[S["pipe"]]),
    c(17, "abstention_layer", "B. Infrastructure", ["ai/abstention.py"], "Explicit insufficient-evidence response with reason codes; no AI call.", "deterministic", "Thresholds are configuration defaults.", [U["misc"]]),
    c(18, "ai_logging", "B. Infrastructure", ["ai/audit.py"], "Request ID, model, prompt versions, evidence IDs, validation outcome, timestamp.", "-", "-", [U["misc"]]),
    c(19, "retry_manager", "B. Infrastructure", ["ai/retry.py"], "Bounded exponential backoff; fatal errors not retried; exhaustion raises.", "-", "-", [U["retry"]], integ=[I["fail"]], fail=[U["retry"], I["fail"]]),
    c(20, "response_cache", "B. Infrastructure", ["ai/cache.py"], "Caches only validated OK responses; key binds to role/district scope, versions, evidence fingerprint.", "-", "In-process only.", [U["misc"]]),
    c(21, "dataset_generator", "C. Evaluation", ["evaluation/generate_cases.py", "evaluation/dataset.jsonl"], "141 seeded SYNTHETIC cases with construction labels and independent arithmetic.", "-", "Labels reflect how cases were built; not real-world ground truth.", [E], integ=[E], sec=[E], demo="evaluation"),
    c(22, "factual_accuracy", "C. Evaluation", ["evaluation/factual_accuracy.py"], "Recall of independently computed facts in accepted outputs.", "harness", "Does not assess language quality.", [E], integ=[E], sec=[E], demo="evaluation"),
    c(23, "numeric_accuracy", "C. Evaluation", ["evaluation/numeric_accuracy.py"], "Numeric error rate vs independent values; numeric-defect detection.", "harness", "Many values (counts, z-scores) are not independently verifiable and are reported as such.", [E], integ=[E], sec=[E], demo="evaluation"),
    c(24, "hallucination_evaluation", "C. Evaluation", ["evaluation/hallucination.py"], "Unsupported-claim rate and injected-hallucination detection.", "harness", "-", [E], integ=[E], sec=[E], demo="evaluation"),
    c(25, "source_attribution", "C. Evaluation", ["evaluation/source_grounding.py"], "Attribution accuracy and bad-reference detection.", "harness", "-", [E], integ=[E], sec=[E], demo="evaluation"),
    c(26, "contradiction_evaluation", "C. Evaluation", ["evaluation/runner.py"], "Precision/recall/F1 for labelled conflicts.", "harness", "-", [E], integ=[E], sec=[E], demo="evaluation"),
    c(27, "missing_data_evaluation", "C. Evaluation", ["evaluation/harness.py"], "Missing required/optional evidence cases.", "harness", "-", [E], integ=[E], sec=[E], demo="evaluation"),
    c(28, "stale_data_evaluation", "C. Evaluation", ["evaluation/runner.py"], "Stale primary/secondary evidence detection.", "harness", "-", [E], integ=[E], sec=[E], demo="evaluation"),
    c(29, "abstention_evaluation", "C. Evaluation", ["evaluation/runner.py"], "Abstention precision/recall/F1.", "harness", "-", [E], integ=[E], sec=[E], demo="evaluation"),
    c(30, "robustness_evaluation", "C. Evaluation", ["evaluation/robustness.py"], "Malformed/adversarial/unauthorised input handling by difficulty; hard cases expose gaps.", "harness", "Two 'hard' injection cases currently FAIL by design of the heuristic detector.", [E], integ=[E], sec=[E], demo="evaluation"),
    c(31, "regression_testing", "C. Evaluation", ["evaluation/regression.py"], "Baseline, prompt-version and provider comparison; detects prompt 1.1.0 regression.", "harness", "-", [E], integ=[E], sec=[E], demo="evaluation"),
    c(32, "evaluation_dashboard", "C. Evaluation", ["evaluation/report.py", "dashboard/eval_dashboard.html"], "Static dashboard + markdown report rendered ONLY from results.json.", "runner", "Static HTML; no live updates.", [E], integ=[E], sec=[E], demo="evaluation"),
    c(33, "prompt_injection_defence", "D. Security", ["security/prompt_injection.py"], "Heuristic detection on questions; quarantine of untrusted evidence text.", "-", "Paraphrased / non-English injections evade it (documented in tests and report).", [S["comp"]], sec=[S["comp"], S["pipe"]], fail=[S["comp"]]),
    c(34, "input_sanitisation", "D. Security", ["security/input_validation.py"], "Types, lengths, characters, district IDs, parameter allow-list, privilege-parameter rejection.", "districts", "-", [S["comp"]], sec=[S["comp"], S["pipe"]], fail=[S["comp"]]),
    c(35, "output_safety", "D. Security", ["security/output_safety.py"], "Rejects funding/action recommendations, review bypass, status override, absolute claims.", "-", "Regex based.", [S["comp"]], sec=[S["comp"], S["pipe"]], fail=[S["comp"]]),
    c(36, "access_control", "D. Security", ["security/access_control.py"], "Token authentication separate from role/district authorisation; role never read from request.", "-", "Reference UserDirectory; NOT yet wired to the repo's access_control.csv/identity source.", [S["comp"]], sec=[S["comp"], S["pipe"]], fail=[S["comp"]], cap="SECURITY_VERIFIED"),
    c(37, "data_minimisation", "D. Security", ["security/data_minimisation.py"], "Allow-listed evidence fields only; per-task minimal contexts.", "-", "-", [U["retr"]], sec=[S["pipe"]]),
    c(38, "audit_integration", "D. Security", ["ai/audit.py", "ai/master_pipeline.py"], "Hash-chained ledger of AI requests, validation failures, denials, human reviews.", "-", "Local ledger; NOT yet connected to the repo's own audit system.", [U["misc"]], sec=[S["pipe"]], cap="SECURITY_VERIFIED"),
]

# Components that cannot honestly be called COMPLETE yet (reason in each component's limitations text):
#  - AI analysts / prompts: only exercised with the deterministic mock, never with a real model
#  - prompt-injection defence: two known 'hard' evasions are failing in the evaluation lab
_CAPPED = {"evidence_analyst", "contradiction_analyst", "anomaly_explainer", "policy_brief", "uncertainty_explainer",
           "recommendation_explainer", "prompt_manager", "prompt_injection_defence", "robustness_evaluation"}
for _c in COMPONENTS:
    if _c["key"] in _CAPPED:
        _c["cap"] = "SECURITY_VERIFIED"
