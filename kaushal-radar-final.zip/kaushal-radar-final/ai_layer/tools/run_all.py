"""One command: unit+integration+security+evaluation tests, evaluation lab, demo, registry.   python -m tools.run_all"""
import subprocess
import sys

STEPS = [["-m", "unittest", "discover", "-s", "tests", "-t", "."], ["-m", "evaluation.runner"], ["-m", "demo.run_demo"], ["-m", "tools.build_registry"]]
rc = 0
for s in STEPS:
    print("\n$ python " + " ".join(s))
    rc |= subprocess.call([sys.executable] + s)
sys.exit(rc)
