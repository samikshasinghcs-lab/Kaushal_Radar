"""Input sanitisation: types, lengths, characters, district IDs and allowed parameters."""
import re
import unicodedata
from dataclasses import dataclass

from ai import districts
from ai.exceptions import InputRejected

ALLOWED_KEYS = {"question", "district_id"}
PRIVILEGE_KEYS = {"role", "roles", "user", "user_id", "userid", "username", "permissions", "permission",
                  "is_admin", "admin", "districts", "scope", "clearance", "token", "auth", "identity"}
_CONTROL = re.compile(r"[\x00-\x08\x0b-\x1f\x7f]")
_ALLOWED_CHARS = re.compile(r"^[\w\s.,?!'’\"()\-/:%&+]+$", re.UNICODE)


@dataclass(frozen=True)
class ValidatedRequest:
    question: str
    district_id: str | None


def normalise_question(q):
    q = unicodedata.normalize("NFKC", q)
    q = re.sub(r"[\u200b\u200c\u200d\u2060\ufeff]", "", q)
    return re.sub(r"\s+", " ", q).strip()


def validate_request(payload, max_chars=500):
    if not isinstance(payload, dict):
        raise InputRejected("request body must be a JSON object", code="BAD_BODY")
    for k in payload:
        if not isinstance(k, str):
            raise InputRejected("non-string key", code="BAD_KEY")
        if k.lower() in PRIVILEGE_KEYS:
            raise InputRejected("identity or privilege parameters are not accepted in requests",
                                code="PRIVILEGE_PARAMETER_REJECTED")
        if k not in ALLOWED_KEYS:
            raise InputRejected(f"unknown parameter '{k[:30]}'", code="UNKNOWN_PARAMETER")
    q = payload.get("question")
    if not isinstance(q, str):
        raise InputRejected("question must be a string", code="BAD_QUESTION_TYPE")
    if len(q) > max_chars * 4:
        raise InputRejected("question too long", code="QUESTION_TOO_LONG")
    if _CONTROL.search(q):
        raise InputRejected("control characters are not allowed", code="CONTROL_CHARS")
    q = normalise_question(q)
    if not q:
        raise InputRejected("question is empty", code="QUESTION_EMPTY")
    if len(q) > max_chars:
        raise InputRejected("question too long", code="QUESTION_TOO_LONG")
    if "--" in q or not _ALLOWED_CHARS.match(q):
        raise InputRejected("question contains disallowed characters", code="DISALLOWED_CHARS")
    did = payload.get("district_id")
    if did is not None:
        if not isinstance(did, str) or not districts.is_valid_id(did):
            raise InputRejected("invalid district identifier", code="INVALID_DISTRICT")
    return ValidatedRequest(q, did)
