"""Data minimisation: only allow-listed fields of authorised evidence ever reach the LLM."""
ALLOWED_EVIDENCE_FIELDS = ("evidence_id", "metric", "value", "unit", "period", "source_id", "definition",
                           "denominator_basis", "as_of", "data_class", "role")


def minimise_evidence(record):
    return {k: record[k] for k in ALLOWED_EVIDENCE_FIELDS if k in record}


def minimise_records(records, limit):
    return [minimise_evidence(r) for r in records[:limit]]
