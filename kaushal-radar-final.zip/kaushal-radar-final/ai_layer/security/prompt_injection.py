"""Prompt-injection defence (heuristic). Retrieved documents and user text are UNTRUSTED.

Limitations (documented honestly): pattern based; paraphrased or non-English injections can evade it.
It is one layer: the real protections are schema validation, grounding, numeric checks and the
fact that the model has no tools and cannot change decisions.
"""
import re
import unicodedata

_ZW = re.compile("[\u200b\u200c\u200d\u2060\ufeff\u00ad]")
_LEET = str.maketrans({"1": "i", "0": "o", "3": "e", "@": "a", "$": "s", "5": "s", "7": "t", "!": "i"})

_PATTERNS = [
    ("IGNORE_INSTRUCTIONS", r"\b(ignore|disregard|forget|override|bypass|skip)\b.{0,40}\b(previous|prior|above|earlier|all|any|your|the|these|those)\b.{0,30}\b(instruction|instructions|rules|prompt|prompts|guidelines|constraints|checks|validation|guard|guards)\b"),
    ("ROLE_HIJACK", r"\b(you are now|act as|pretend (to be|you)|from now on you|new persona|developer mode|jailbreak|dan mode)\b"),
    ("PROMPT_LEAK", r"\b(reveal|show|print|repeat|leak|output)\b.{0,30}\b(system prompt|your prompt|your instructions|api key|secret|credentials|token)\b"),
    ("NEW_INSTRUCTIONS", r"\b(new|updated|real|actual) instructions?\b|\binstead,? (you )?(must|should|will)\b"),
    ("DECISION_OVERRIDE", r"\b(approve|authori[sz]e|sanction|release)\b.{0,25}\b(fund|funds|funding|budget|grant)\b|\boverride\b.{0,30}\b(decision|engine|status|human review)\b|\bmark (this|it|the district)\b.{0,20}\b(verified|approved|safe)\b"),
    ("SOURCE_SUPPRESSION", r"\b(do not|don't|never|without)\b.{0,15}\b(cite|citing|use|using|mention)\b.{0,15}\b(evidence|sources?|references?)\b"),
    ("CHAT_MARKUP", r"(</?\s*(system|assistant|developer)\s*>|\[/?(inst|system)\]|^\s*system\s*:|```\s*system|begin (system|admin) (prompt|message))"),
    ("CODE_EXEC", r"\b(exec|eval|os\.system|subprocess|__import__)\s*\(|\bimport\s+(os|subprocess|sys)\b|\bdrop\s+table\b|\bunion\s+select\b"),
]
_COMPILED = [(n, re.compile(p, re.I | re.S | re.M)) for n, p in _PATTERNS]


def normalise(text):
    t = unicodedata.normalize("NFKC", str(text))
    t = _ZW.sub("", t)
    return re.sub(r"\s+", " ", t)


def scan_text(text):
    if not isinstance(text, str) or not text:
        return {"detected": False, "matches": []}
    base = normalise(text)
    variants = [base.lower(), base.lower().translate(_LEET)]
    matches = []
    for name, rx in _COMPILED:
        if any(rx.search(v) for v in variants):
            matches.append(name)
    return {"detected": bool(matches), "matches": sorted(set(matches))}


def assert_clean(text, label="input"):
    from ai.exceptions import PromptInjectionDetected
    res = scan_text(text)
    if res["detected"]:
        raise PromptInjectionDetected(f"possible prompt injection in {label}",
                                      code="PROMPT_INJECTION", details={"matches": res["matches"]})
    return text


INJECTABLE_FIELDS = ("definition", "denominator_basis", "notes", "period")


def quarantine_records(records):
    """Split records into (safe, quarantined). Quarantined records never reach a model."""
    safe, quarantined = [], []
    for r in records:
        hit = None
        for f in INJECTABLE_FIELDS:
            res = scan_text(r.get(f, ""))
            if res["detected"]:
                hit = {"evidence_id": r["evidence_id"], "field": f, "matches": res["matches"]}
                break
        (quarantined if hit else safe).append(hit or r)
    return safe, quarantined
