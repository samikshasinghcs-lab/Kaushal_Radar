"""Security package. NOTE: the repository's legacy module was renamed security_legacy.py to avoid
shadowing by this package; keep it that way."""
