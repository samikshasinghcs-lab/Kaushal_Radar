"""Authentication (token -> identity) and authorisation (role -> permissions, district scope).

Identity and role come ONLY from the server-side directory. A request can never choose its own role.
`UserDirectory` is a self-contained reference implementation (PBKDF2-hashed tokens). Wire it to the
repository's real identity source / access_control.csv before production use.
"""
import hashlib
import hmac
import os
import secrets
from dataclasses import dataclass

from ai.exceptions import AccessDenied, AuthenticationError, ConfigError

ROLE_PERMISSIONS = {
    "DISTRICT_OFFICER": {"query_district", "review_brief"},
    "ANALYST": {"query_district"},
    "STATE_OFFICER": {"query_district", "review_brief", "view_restricted_evidence", "view_all_districts"},
    "AUDITOR": {"view_audit"},
    "ADMIN": {"manage_users"},
}
DISTRICT_SCOPED = {"query_district", "review_brief"}
PBKDF2_ITERATIONS = 20000


@dataclass(frozen=True)
class Identity:
    user_id: str
    role: str
    districts: frozenset

    def permissions(self):
        return ROLE_PERMISSIONS.get(self.role, set())

    def has(self, permission):
        return permission in self.permissions()


def can_access_district(identity, district_id):
    return identity.has("view_all_districts") or district_id in identity.districts


def authorize(identity, permission, district_id=None):
    if not isinstance(identity, Identity):
        raise AccessDenied("no identity", code="ACCESS_DENIED")
    if not identity.has(permission):
        raise AccessDenied("permission denied", code="PERMISSION_DENIED")
    if permission in DISTRICT_SCOPED:
        if district_id is None or not can_access_district(identity, district_id):
            raise AccessDenied("district access denied", code="DISTRICT_ACCESS_DENIED")
    return True


def _hash(token, salt):
    return hashlib.pbkdf2_hmac("sha256", token.encode(), salt, PBKDF2_ITERATIONS)


class UserDirectory:
    def __init__(self):
        self._users = {}

    def register(self, user_id, role, districts=(), token=None, active=True):
        if role not in ROLE_PERMISSIONS:
            raise ConfigError(f"unknown role {role}")
        token = token or secrets.token_urlsafe(24)
        salt = os.urandom(16)
        self._users[user_id] = {"salt": salt, "hash": _hash(token, salt), "role": role,
                                "districts": frozenset(districts), "active": active}
        return token

    def deactivate(self, user_id):
        self._users[user_id]["active"] = False

    def authenticate(self, token):
        if not isinstance(token, str) or not (8 <= len(token) <= 256):
            raise AuthenticationError("invalid credentials")
        match, found = None, False
        for uid, u in self._users.items():  # iterate all users: no early exit
            ok = hmac.compare_digest(_hash(token, u["salt"]), u["hash"])
            if ok and u["active"] and not found:
                match, found = uid, True
        if not found:
            raise AuthenticationError("invalid credentials")
        u = self._users[match]
        return Identity(match, u["role"], u["districts"])
