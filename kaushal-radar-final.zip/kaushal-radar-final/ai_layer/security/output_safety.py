"""Output safety: reject recommendations of departmental action, funding decisions, or review bypass."""
import re

_ACTION = r"(approv\w*|sanction\w*|releas\w*|disburs\w*|allocat\w*|reallocat\w*|cancel\w*|suspend\w*|terminat\w*|defund\w*|penali[sz]\w*|shut\w* down|clos\w*)"
_OBJECT = r"(fund|funds|funding|budget|grant|grants|scheme|programme|program|centre|center|institute|institution|contract|payment|subsidy|licen[cs]e)"
_PATTERNS = [
    ("FUNDING_OR_ACTION_DECISION", re.compile(rf"\b{_ACTION}\b[^.]{{0,40}}\b{_OBJECT}\b|\b{_OBJECT}\b[^.]{{0,25}}\b{_ACTION}\b", re.I)),
    ("PRESCRIPTIVE_ACTION", re.compile(r"\b(should|must|need to|ought to)\s+(be\s+)?(funded|defunded|closed|cancelled|canceled|suspended|terminated|penali[sz]ed|sanctioned|approved)\b", re.I)),
    ("REVIEW_BYPASS", re.compile(r"\b(bypass|skip|waive|no need for)\b[^.]{0,20}\b(human )?review\b|\breview (is )?(not|un)(needed|necessary|required)\b", re.I)),
    ("DECISION_OVERRIDE", re.compile(r"\b(override|overrule|change|upgrade|downgrade)\b[^.]{0,25}\b(decision engine|engine status|status)\b", re.I)),
    ("ABSOLUTE_CLAIM", re.compile(r"\b(guarantee[sd]?|proves?|definitely|certainly|undeniabl\w+|beyond doubt)\b", re.I)),
]


def check_text(text):
    return [name for name, rx in _PATTERNS if rx.search(text or "")]


def check_output(output):
    violations = []
    texts = [("summary", output.get("summary", ""))] + [(c["claim_id"], c["text"]) for c in output.get("claims", [])]
    for where, text in texts:
        for code in check_text(text):
            violations.append({"code": "OUTPUT_UNSAFE_" + code, "claim_id": where, "detail": code})
    return violations
