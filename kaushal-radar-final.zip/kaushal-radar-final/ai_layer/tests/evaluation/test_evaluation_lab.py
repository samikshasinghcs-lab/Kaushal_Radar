import json
import os
import re
import tempfile
import unittest
from unittest import mock

from evaluation import generate_cases, regression, report, runner
from evaluation.harness import load_dataset, run_case

REQUIRED_SCENARIOS = {"clean_evidence", "conflicting_evidence", "missing_evidence", "stale_evidence", "incorrect_numeric_claims",
                      "unsupported_source_refs", "prompt_injection", "invalid_district_ids", "denominator_changes", "low_confidence",
                      "insufficient_evidence", "malformed_inputs"}
FIELDS = {"case_id", "scenario", "input", "expected_behaviour", "expected_facts", "expected_sources", "severity"}


class DatasetTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cases = load_dataset(runner.DATASET)

    def test_size_scenarios_fields_and_uniqueness(self):
        self.assertGreaterEqual(len(self.cases), 120)
        self.assertTrue(REQUIRED_SCENARIOS <= {c["scenario"] for c in self.cases})
        self.assertEqual(len({c["case_id"] for c in self.cases}), len(self.cases))
        for c in self.cases:
            self.assertTrue(FIELDS <= set(c), c["case_id"])
            self.assertEqual(c["label_origin"], "SYNTHETIC_CONSTRUCTED")

    def test_committed_dataset_is_reproducible_from_generator(self):
        with tempfile.TemporaryDirectory() as td:
            path, _ = generate_cases.write(os.path.join(td, "d.jsonl"))
            with open(path) as a, open(runner.DATASET) as b:
                self.assertEqual(a.read(), b.read())

    def test_generator_does_not_import_code_under_test(self):
        with open(generate_cases.__file__) as fh:
            src = fh.read()
        imports = re.findall(r"^\s*(?:from|import)\s+([\w.]+)", src, re.M)
        self.assertFalse([m for m in imports if m in ("ai.deterministic", "ai.numeric_guard", "ai.master_pipeline", "ai.source_grounding")], imports)
        self.assertIn("ai.evidence_store import peer_raw", src)  # data only

    def test_all_numeric_labels_match_hand_arithmetic(self):
        c = self.cases[0]
        nums = {f["ref"]: f["value"] for f in c["expected_facts"] if f["type"] == "number"}
        raw = c["input"]["raw"]
        self.assertEqual(nums["IND_GVR"], round(raw["graduates_total"] / raw["vacancies_total"], 2))


class RunnerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.res = runner.run()

    def test_every_case_executed_and_counts_consistent(self):
        r = self.res
        self.assertEqual(len(r["results"]), r["dataset"]["cases"])
        self.assertEqual(r["overall"]["passed"] + r["overall"]["failed"], r["dataset"]["cases"])
        self.assertEqual(len(r["failures"]), r["overall"]["failed"])

    def test_reported_metrics_present(self):
        r = self.res
        for k in ("contradiction_detection", "abstention", "stale_detection"):
            for m in ("precision", "recall", "f1"):
                self.assertIn(m, r[k])
        self.assertIn("numeric_error_rate", r["numeric"])
        self.assertIn("unsupported_claim_rate", r["hallucination"])
        self.assertIn("source_attribution_accuracy", r["source_attribution"])
        self.assertFalse(r["overall"]["reviewed_by_human"])
        self.assertTrue(any("SYNTHETIC" in c for c in r["caveats"]))

    def test_quality_floor_but_not_claimed_perfect(self):
        r = self.res
        self.assertGreaterEqual(r["overall"]["behaviour_accuracy"], 0.95)
        self.assertEqual(r["numeric"]["numeric_error_rate"], 0.0)
        # hard adversarial cases are expected to expose detector gaps: the lab must surface them, not hide them
        hard = [x for x in r["results"] if x["difficulty"] == "hard"]
        self.assertTrue(hard and any(not x["passed"] for x in hard))
        self.assertTrue(all(f["case_id"] in {x["case_id"] for x in r["results"]} for f in r["failures"]))

    def test_guards_catch_all_defective_provider_outputs(self):
        for mode, v in self.res["provider_comparison"].items():
            if mode.startswith("sloppy"):
                self.assertEqual(v["defective_outputs_accepted"], 0, mode)

    def test_prompt_version_regression_detects_bad_candidate(self):
        # evidence_analyst@1.1.0 (round ratios to 1 dp) is a deliberately risky candidate: for some cases the rounding
        # exceeds the numeric tolerance. The regression harness must surface that so the prompt is NOT promoted.
        p = self.res["prompt_version_comparison"]
        self.assertGreater(p["cases"], 20)
        self.assertGreater(len(p["regressions"]), 0)
        self.assertLess(p["pass_to"], p["pass_from"])

    def test_baseline_comparison_detects_regression(self):
        base = [{"case_id": "A", "passed": True}, {"case_id": "B", "passed": False}]
        cur = [{"case_id": "A", "passed": False}, {"case_id": "B", "passed": True}, {"case_id": "C", "passed": True}]
        d = regression.compare(base, cur)
        self.assertEqual((d["regressions"], d["fixes"], d["new_cases"]), (["A"], ["B"], ["C"]))

    def test_report_and_dashboard_are_rendered_from_results_only(self):
        with tempfile.TemporaryDirectory() as td:
            md, html = os.path.join(td, "r.md"), os.path.join(td, "d.html")
            report.write_markdown(self.res, md)
            report.write_dashboard(self.res, html)
            with open(md) as a, open(html) as b:
                text, page = a.read(), b.read()
        self.assertIn(f"**{self.res['overall']['failed']}**", text)
        self.assertIn("SYNTHETIC", page)
        self.assertNotIn("<script", page)  # nothing computed client-side
        for f in self.res["failures"]:
            self.assertIn(f["case_id"], page)


class EvaluatorIndependenceTests(unittest.TestCase):
    """If the code under test is subtly wrong but self-consistent, the independent labels must catch it."""

    def test_buggy_indicator_calculation_is_caught_by_independent_labels(self):
        from ai import deterministic as det
        orig = det.compute_indicators

        def buggy(records):
            out = orig(records)
            if "IND_GVR" in out:
                out["IND_GVR"] = dict(out["IND_GVR"], value=round(out["IND_GVR"]["value"] * 1.2, 2))
            return out
        clean = [c for c in load_dataset(runner.DATASET) if c["scenario"] == "clean_evidence"]
        with mock.patch.object(det, "compute_indicators", buggy):
            res = [run_case(c) for c in clean]
        # guards compare the AI to the (buggy) deterministic values so outputs are internally consistent...
        self.assertTrue(any(r["observed"] == "ACCEPT" for r in res))
        # ...but the evaluator, using independently computed numbers, must flag the error.
        self.assertTrue(any(r["metrics"]["numeric_wrong"] > 0 for r in res))
        self.assertTrue(any(not r["passed"] for r in res))


if __name__ == "__main__":
    unittest.main()
