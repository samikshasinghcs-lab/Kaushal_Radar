"""Each analyst works independently of the master pipeline: context -> provider -> schema -> guards."""
import unittest

from ai import hallucination_guard, numeric_guard, source_grounding
from ai.context_builder import build_context
from ai.decision_gate import DecisionGate
from ai.abstention import decide
from ai.provider import MockProvider, ProviderManager
from security import output_safety
from tests.helpers import raichur_bundle


def run_task(task, role="STATE_OFFICER"):
    store, r, b = raichur_bundle(role)
    b.decision = DecisionGate().evaluate(b, decide(b, b.config))
    pm = ProviderManager(MockProvider(), b.config, sleep=lambda s: None)
    out = pm.complete_json(task, build_context(task, b, b.config)).output
    v = (source_grounding.check(out, b, store) + numeric_guard.check(out, b, b.config)
         + hallucination_guard.check(out, b, b.decision if task == "recommendation_explainer" else None) + output_safety.check_output(out))
    return out, v, b


class AnalystTests(unittest.TestCase):
    def test_every_analyst_is_valid_and_traceable(self):
        for task in ("evidence_analyst", "contradiction_analyst", "anomaly_explainer", "uncertainty_explainer",
                     "recommendation_explainer", "policy_brief"):
            with self.subTest(task=task):
                out, v, _ = run_task(task)
                self.assertEqual(v, [], v)
                self.assertTrue(out["claims"])
                for c in out["claims"]:
                    if c["kind"] in ("fact", "interpretation"):
                        self.assertTrue(c["evidence_ids"] or c["indicator_ids"])

    def test_evidence_analyst_cites_source_ids_and_values(self):
        out, _, b = run_task("evidence_analyst")
        c = out["claims"][0]
        self.assertIn("EV_023_GRADUATES_TOTAL", c["evidence_ids"])
        self.assertIn("8.76", c["text"])

    def test_contradiction_analyst_distinguishes_types(self):
        out, _, _ = run_task("contradiction_analyst")
        text = " ".join(c["text"] for c in out["claims"])
        for t in ("GENUINE", "MEASUREMENT_DIFFERENCE", "CROSS_INDICATOR_TENSION"):
            self.assertIn(t, text)

    def test_anomaly_explainer_only_explains_deterministic_anomalies(self):
        out, _, b = run_task("anomaly_explainer")
        self.assertEqual(len(out["claims"]), len(b.anomalies))

    def test_uncertainty_explainer_covers_stale_denominator_ranking(self):
        out, _, _ = run_task("uncertainty_explainer")
        text = " ".join(c["text"] for c in out["claims"])
        self.assertIn("days old", text)
        self.assertIn("denominator basis", text)
        self.assertIn("Ranking is", text)

    def test_recommendation_explainer_cannot_change_status(self):
        out, _, b = run_task("recommendation_explainer")
        self.assertIn(b.decision["status"], out["claims"][0]["text"])

    def test_policy_brief_only_suggests_investigations(self):
        out, _, _ = run_task("policy_brief")
        self.assertTrue(all(c["kind"] == "suggestion" for c in out["claims"]))

    def test_restricted_contradiction_only_for_cleared_role(self):
        _, _, bs = run_task("contradiction_analyst", "STATE_OFFICER")
        _, _, bd = run_task("contradiction_analyst", "DISTRICT_OFFICER")
        self.assertIn("GENUINE", {c["type"] for c in bs.contradictions})
        self.assertNotIn("GENUINE", {c["type"] for c in bd.contradictions})


if __name__ == "__main__":
    unittest.main()
