import unittest
from datetime import date

from ai.config import Config
from ai.deterministic import compute_indicators, find_anomalies, find_contradictions, find_denominator_changes, find_stale, rank_desc
from ai.evidence_store import SOURCES, make_record, RAICHUR, RAICHUR_RAW, records_from_raw
from tests.helpers import raichur_bundle


class DeterministicTests(unittest.TestCase):
    def test_indicator_values_hand_checked(self):
        ind = compute_indicators(records_from_raw(RAICHUR, RAICHUR_RAW))
        self.assertEqual(ind["IND_GVR"]["value"], 8.76)       # 18400/2100
        self.assertEqual(ind["IND_PLR"]["value"], 81.03)      # 2350/2900
        self.assertEqual(ind["IND_TUR"]["value"], 90.62)      # 2900/3200
        self.assertEqual(ind["IND_GPC"]["value"], 11.15)      # 18400/1,650,000*1000

    def test_zero_denominator_not_computed(self):
        raw = dict(RAICHUR_RAW, vacancies_total=0)
        self.assertNotIn("IND_GVR", compute_indicators(records_from_raw(RAICHUR, raw)))

    def test_contradiction_types(self):
        cfg = Config()
        base = make_record(RAICHUR, "placed_total", 1000)
        same_def = make_record(RAICHUR, "placed_total", 700, role="secondary", suffix="_S1")
        other_def = make_record(RAICHUR, "placed_total", 700, role="secondary", suffix="_S2", definition="Different definition")
        close_val = make_record(RAICHUR, "placed_total", 950, role="secondary", suffix="_S3")
        c = find_contradictions([base, same_def, other_def, close_val], {}, cfg)
        self.assertEqual(sorted(x["type"] for x in c), ["GENUINE", "MEASUREMENT_DIFFERENCE"])

    def test_stale_detection(self):
        r = [make_record(RAICHUR, "graduates_total", 1, as_of="2024-01-01"), make_record(RAICHUR, "vacancies_total", 1)]
        s = find_stale(r, SOURCES, date(2026, 10, 31))
        self.assertEqual([x["evidence_id"] for x in s], ["EV_023_GRADUATES_TOTAL"])

    def test_denominator_changes(self):
        a = make_record(RAICHUR, "working_age_population", 100)
        b = make_record(RAICHUR, "working_age_population", 130, role="secondary", suffix="_S1", basis="census_2011")
        self.assertEqual(find_denominator_changes([a, b])[0]["delta_pct"], 23.08)
        self.assertEqual(find_denominator_changes([a]), [])

    def test_anomaly_needs_peers_and_threshold(self):
        ind = {"IND_GVR": {"value": 10, "name": "g", "unit": "ratio", "inputs": []}}
        self.assertEqual(find_anomalies(ind, {"IND_GVR": [1, 2, 3]}, Config()), [])  # too few peers
        a = find_anomalies(ind, {"IND_GVR": [2, 2.1, 2.2, 2.3, 2.4, 2.5]}, Config())
        self.assertEqual(a[0]["direction"], "above")

    def test_rank(self):
        self.assertEqual(rank_desc(5, [1, 9, 3, 7]), 3)

    def test_bundle_raichur(self):
        _, _, b = raichur_bundle()
        self.assertEqual(b.flag["status"], "FLAGGED")
        self.assertEqual(b.flag["threshold"], round(1.5 * b.flag["peer_median"], 2))
        self.assertEqual(len(b.contradictions), 3)
        self.assertIn("SYNTHETIC", b.data_classes)

    def test_synthetic_confidence_never_high(self):
        from ai.deterministic import _confidence
        self.assertEqual(_confidence([], [], [], {}, ["SYNTHETIC"])["level"], "MEDIUM")
        self.assertEqual(_confidence([], [], [], {}, ["VERIFIED_OFFICIAL"])["level"], "HIGH")


if __name__ == "__main__":
    unittest.main()
