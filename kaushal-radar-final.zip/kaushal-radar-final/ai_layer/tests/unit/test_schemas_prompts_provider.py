import json
import unittest

from ai import config, prompts
from ai.exceptions import ConfigError, MalformedOutput, ProviderFatal, ProviderRateLimit, SchemaValidationError
from ai.mock_analysts import generate
from ai.provider import AnthropicProvider, MockProvider, ProviderManager, RateLimiter, parse_json_output
from ai.schemas import ANALYST_OUTPUT_SCHEMA, validate
from tests.helpers import raichur_bundle
from ai.context_builder import build_context


class SchemaTests(unittest.TestCase):
    def test_valid_mock_output_passes(self):
        _, _, b = raichur_bundle()
        b.decision = {"status": "X", "reason_codes": []}
        out = generate("evidence_analyst", build_context("evidence_analyst", b, b.config), "1.0.0")
        validate(out, ANALYST_OUTPUT_SCHEMA)

    def test_rejects_extra_missing_and_bad_types(self):
        _, _, b = raichur_bundle()
        out = generate("anomaly_explainer", build_context("anomaly_explainer", b, b.config), "1.0.0")
        for mutate in (lambda o: o.update(extra=1), lambda o: o.pop("claims"), lambda o: o.update(confidence="CERTAIN"),
                       lambda o: o["claims"][0].update(evidence_ids="EV_1"), lambda o: o["claims"][0]["numbers"].append({"name": "x", "value": True, "unit": "ratio", "ref": "IND_X"})):
            bad = json.loads(json.dumps(out))
            mutate(bad)
            with self.assertRaises(SchemaValidationError):
                validate(bad, ANALYST_OUTPUT_SCHEMA)

    def test_nan_and_bool_not_numbers(self):
        with self.assertRaises(SchemaValidationError):
            validate(float("nan"), {"type": "number"})
        with self.assertRaises(SchemaValidationError):
            validate(True, {"type": "number"})


class PromptTests(unittest.TestCase):
    def test_versions_explicit_and_unknown_rejected(self):
        self.assertEqual(prompts.get_prompt("evidence_analyst").version, "1.0.0")
        self.assertEqual(prompts.get_prompt("evidence_analyst", "1.1.0").version, "1.1.0")
        with self.assertRaises(KeyError):
            prompts.get_prompt("evidence_analyst", "9.9.9")
        self.assertIn("untrusted", prompts.get_prompt("policy_brief").system)


class ProviderTests(unittest.TestCase):
    def test_mock_is_deterministic(self):
        _, _, b = raichur_bundle()
        b.decision = {"status": "S", "reason_codes": []}
        ctx = build_context("uncertainty_explainer", b, b.config)
        kw = dict(task="uncertainty_explainer", system="s", prompt="p", context=ctx, prompt_version="1.0.0")
        self.assertEqual(MockProvider().complete(**kw).text, MockProvider().complete(**kw).text)

    def test_parse_json_strict(self):
        self.assertEqual(parse_json_output('```json\n{"a":1}\n```'), {"a": 1})
        for bad in ("", "nope", "[1]", None):
            with self.assertRaises(MalformedOutput):
                parse_json_output(bad)

    def test_anthropic_adapter_with_injected_transport(self):
        seen = {}

        def ok(url, headers, body, timeout):
            seen.update(url=url, headers=headers, timeout=timeout)
            return 200, json.dumps({"content": [{"type": "text", "text": "{}"}]}).encode()
        p = AnthropicProvider("m", 5, transport=ok, env={"ANTHROPIC_API_KEY": "sk-test"})
        self.assertEqual(p.complete(task="t", system="s", prompt="p", context={}, prompt_version="1.0.0").text, "{}")
        self.assertEqual(seen["headers"]["x-api-key"], "sk-test")
        self.assertEqual(seen["timeout"], 5)
        for status, exc in ((429, ProviderRateLimit), (401, ProviderFatal)):
            p = AnthropicProvider("m", transport=lambda *a, s=status: (s, b"{}"), env={"ANTHROPIC_API_KEY": "k"})
            with self.assertRaises(exc):
                p.complete(task="t", system="s", prompt="p", context={}, prompt_version="1.0.0")

    def test_missing_key_is_config_error_and_never_in_repr(self):
        p = AnthropicProvider("m", transport=lambda *a: (200, b"{}"), env={})
        with self.assertRaises(ConfigError):
            p.complete(task="t", system="s", prompt="p", context={}, prompt_version="1.0.0")
        self.assertNotIn("sk-", repr(config.Config()))

    def test_rate_limiter_token_bucket(self):
        t = [0.0]
        rl = RateLimiter(2, clock=lambda: t[0])
        rl.acquire(); rl.acquire()
        with self.assertRaises(ProviderRateLimit):
            rl.acquire()
        t[0] = 31.0
        rl.acquire()

    def test_manager_rejects_wrong_prompt_version_in_output(self):
        class Bad(MockProvider):
            def complete(self, **kw):
                r = super().complete(**kw)
                r.text = r.text.replace('"prompt_version": "1.0.0"', '"prompt_version": "0.0.1"')
                return r
        _, _, b = raichur_bundle()
        b.decision = {"status": "S", "reason_codes": []}
        pm = ProviderManager(Bad(), b.config, sleep=lambda s: None)
        from ai.exceptions import ProviderUnavailable
        with self.assertRaises(ProviderUnavailable):
            pm.complete_json("anomaly_explainer", build_context("anomaly_explainer", b, b.config))


if __name__ == "__main__":
    unittest.main()
