import unittest

from ai.exceptions import InputRejected
from ai.natural_language_query import parse_question


class NLQTests(unittest.TestCase):
    def test_intents_and_district(self):
        self.assertEqual(parse_question("Why is Raichur flagged?")["intent"], "WHY_FLAGGED")
        self.assertEqual(parse_question("Are there contradictions in Mysuru data?")["district_id"], "KA-022")
        self.assertEqual(parse_question("How reliable is the evidence for Raichur?")["intent"], "UNCERTAINTY")
        self.assertEqual(parse_question("Show me Raichur ratio figures")["intent"], "INDICATORS")
        self.assertEqual(parse_question("Brief on Raichur")["intent"], "FULL_BRIEF")

    def test_id_and_param(self):
        self.assertEqual(parse_question("why flagged", "KA-023")["district_name"], "Raichur")
        self.assertEqual(parse_question("Why is KA-023 flagged?")["district_id"], "KA-023")

    def test_rejections(self):
        for q, code, did in (("Why flagged?", "NO_DISTRICT", None), ("Raichur and Mysuru", "MULTIPLE_DISTRICTS", None),
                             ("Why is KA-999 flagged", "INVALID_DISTRICT", None), ("Mysuru?", "DISTRICT_MISMATCH", "KA-023")):
            with self.assertRaises(InputRejected) as cm:
                parse_question(q, did)
            self.assertEqual(cm.exception.code, code)

    def test_output_is_always_an_allow_listed_object(self):
        q = parse_question("DROP TABLE users; Raichur")
        self.assertEqual(set(q), {"intent", "district_id", "district_name"})


if __name__ == "__main__":
    unittest.main()
