import copy
import unittest

from ai import hallucination_guard, numeric_guard, source_grounding
from ai.numeric_guard import extract_numbers
from tests.unit.test_analysts_standalone import run_task


def codes(v):
    return {x["code"] for x in v}


class GuardTests(unittest.TestCase):
    def setUp(self):
        from tests.helpers import raichur_bundle
        self.store, self.r, self.b = raichur_bundle()
        out, _, _ = run_task("evidence_analyst")
        self.out = out

    def mutated(self, fn):
        o = copy.deepcopy(self.out)
        fn(o)
        return o

    def test_clean_output_passes_all(self):
        self.assertEqual(source_grounding.check(self.out, self.b, self.store), [])
        self.assertEqual(numeric_guard.check(self.out, self.b, self.b.config), [])

    def test_fabricated_and_unauthorised_sources(self):
        o = self.mutated(lambda o: o["claims"][0]["evidence_ids"].append("EV_999_FAKE"))
        self.assertIn("UNKNOWN_EVIDENCE", codes(source_grounding.check(o, self.b, self.store)))
        o = self.mutated(lambda o: o["claims"][0]["evidence_ids"].append("EV_017_GRADUATES_TOTAL"))
        self.assertIn("UNAUTHORISED_EVIDENCE", codes(source_grounding.check(o, self.b, self.store)))
        o = self.mutated(lambda o: o["claims"][0].update(text=o["claims"][0]["text"] + " See SRC_MADE_UP."))
        self.assertIn("TEXT_UNKNOWN_ID", codes(source_grounding.check(o, self.b, self.store)))

    def test_missing_refs(self):
        o = self.mutated(lambda o: o["claims"][0].update(evidence_ids=[], indicator_ids=[], numbers=[]))
        self.assertIn("MISSING_REFS", codes(source_grounding.check(o, self.b, self.store)))

    def test_numeric_value_unit_and_undeclared(self):
        o = self.mutated(lambda o: o["claims"][0]["numbers"][2].update(value=9.76))
        self.assertIn("NUMBER_MISMATCH", codes(numeric_guard.check(o, self.b, self.b.config)))
        o = self.mutated(lambda o: o["claims"][0]["numbers"][2].update(unit="percent"))
        self.assertIn("NUMBER_UNIT_MISMATCH", codes(numeric_guard.check(o, self.b, self.b.config)))
        o = self.mutated(lambda o: o["claims"][0].update(text=o["claims"][0]["text"] + " About 4,567 more."))
        self.assertIn("NUMBER_NOT_IN_SOURCE", codes(numeric_guard.check(o, self.b, self.b.config)))

    def test_rounding_tolerance_boundary(self):
        for v, ok in ((8.8, True), (8.7, False), (8.76, True)):
            o = self.mutated(lambda o: o["claims"][0]["numbers"][2].update(value=v))
            self.assertEqual("NUMBER_MISMATCH" not in codes(numeric_guard.check(o, self.b, self.b.config)), ok, v)

    def test_number_extraction_ignores_ids_periods_dates(self):
        self.assertEqual(extract_numbers("EV_023_X 2025-26 on 2026-10-31 KA-023 per 1,000 is 18,400.5 and 3"), [18400.5, 3.0])

    def test_hallucination_rules(self):
        base = lambda text, kind="fact": self.mutated(lambda o: o["claims"].append(
            {"claim_id": "H", "kind": kind, "text": text, "evidence_ids": ["EV_023_GRADUATES_TOTAL"], "indicator_ids": [], "numbers": []}))
        self.b.stale = []  # demo bundle has genuinely stale evidence; clear it to test the unsupported-staleness rule
        for text, kind, code in (("It fell because of poor teaching.", "fact", "UNSUPPORTED_CAUSAL_CLAIM"),
                                 ("Similar to Mysuru.", "fact", "ENTITY_NOT_IN_SCOPE"),
                                 ("The data is outdated.", "fact", "UNSUPPORTED_STALENESS"),
                                 ("This district is not flagged.", "fact", "FLAG_STATUS_MISMATCH")):
            self.assertIn(code, codes(hallucination_guard.check(base(text, kind), self.b)), text)
        o = self.mutated(lambda o: o.update(confidence="HIGH"))
        self.assertIn("CONFIDENCE_INFLATED", codes(hallucination_guard.check(o, self.b)))

    def test_false_negation_of_detected_contradiction(self):
        o = self.mutated(lambda o: o["claims"].append({"claim_id": "H", "kind": "limitation", "text": "No contradictions were found.",
                                                       "evidence_ids": [], "indicator_ids": [], "numbers": []}))
        self.assertIn("FALSE_NEGATION_CONTRADICTION", codes(hallucination_guard.check(o, self.b)))


if __name__ == "__main__":
    unittest.main()
