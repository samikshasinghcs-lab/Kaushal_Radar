"""Provider outage, timeout, rate-limit and malformed output must never become a successful response."""
import unittest

from ai.exceptions import MalformedOutput, ProviderError, ProviderRateLimit, ProviderTimeout
from evaluation.fault_injection import AlwaysFailProvider, FlakyProvider, MutatingProvider
from tests.helpers import make_world

Q = {"question": "Why is Raichur flagged?"}


class FailureTests(unittest.TestCase):
    def assert_fail_closed(self, r):
        self.assertEqual(r["status"], "FAILED_PROVIDER")
        self.assertIsNone(r["brief"])
        self.assertFalse(r["decision"]["presentable_as_verified"])
        self.assertFalse(r["validation"]["passed"])
        self.assertEqual(r["decision"]["status"], "FLAGGED_FOR_REVIEW")  # deterministic result still available, AI absent

    def test_outage_timeout_ratelimit_all_fail_closed(self):
        for exc in (lambda: ProviderTimeout("t"), lambda: ProviderRateLimit("r"), lambda: ProviderError("5xx")):
            with self.subTest(exc=exc().code):
                prov = AlwaysFailProvider(exc)
                p, _, t = make_world(prov)
                self.assert_fail_closed(p.handle_request(t["state"], Q))
                self.assertEqual(prov.calls, 3)  # 1 try + 2 bounded retries
                self.assertIn("AI_REQUEST_FAILED", [e["event_type"] for e in p.ledger.entries()])

    def test_transient_failure_recovers_within_bound(self):
        prov = FlakyProvider([ProviderTimeout("t"), ProviderRateLimit("r")])
        p, _, t = make_world(prov)
        r = p.handle_request(t["state"], Q)
        self.assertEqual((r["status"], r["validation"]["passed"]), ("OK", True))

    def test_malformed_outputs_fail_closed(self):
        for m in ({"task": "evidence_analyst", "op": "raw_text", "text": "not json"},
                  {"task": "evidence_analyst", "op": "raw_text", "text": "[1,2]"},
                  {"task": "anomaly_explainer", "op": "drop_key", "key": "claims"},
                  {"task": "policy_brief", "op": "raw_text", "text": ""}):
            p, _, t = make_world(MutatingProvider([m]))
            self.assert_fail_closed(p.handle_request(t["state"], Q))

    def test_failure_response_contains_no_secrets_or_stack_traces(self):
        p, _, t = make_world(AlwaysFailProvider())
        self.assertNotIn("Traceback", str(p.handle_request(t["state"], Q)))

    def test_local_rate_limit_enforced(self):
        from ai.config import Config
        from ai.provider import MockProvider, ProviderManager, RateLimiter
        from ai.exceptions import ProviderUnavailable
        pm = ProviderManager(MockProvider(), Config(max_retries=0), sleep=lambda s: None, rate_limiter=RateLimiter(1, clock=lambda: 0.0))
        from ai.context_builder import build_context
        from tests.helpers import raichur_bundle
        _, _, b = raichur_bundle()
        ctx = build_context("anomaly_explainer", b, b.config)
        pm.complete_json("anomaly_explainer", ctx)
        with self.assertRaises(ProviderUnavailable):
            pm.complete_json("anomaly_explainer", ctx)


if __name__ == "__main__":
    unittest.main()
