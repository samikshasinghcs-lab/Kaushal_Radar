import os
import tempfile
import unittest

from ai.audit import AuditLedger
from ai.cache import ResponseCache
from tests.helpers import make_world

Q = {"question": "Why is Raichur flagged?"}


class IntegrationTests(unittest.TestCase):
    def test_modules_cooperate_end_to_end(self):
        p, _, t = make_world()
        r = p.handle_request(t["state"], Q)
        self.assertEqual((r["status"], r["validation"]["passed"]), ("OK", True))
        self.assertEqual(r["decision"]["status"], "FLAGGED_FOR_REVIEW")
        self.assertEqual(set(r["validation"]["per_task"]), {"evidence_analyst", "contradiction_analyst", "anomaly_explainer",
                                                            "uncertainty_explainer", "recommendation_explainer", "policy_brief"})
        self.assertEqual(r["human_review"], {"required": True, "status": "PENDING"})
        self.assertTrue(r["brief"]["banner"].startswith("SYNTHETIC"))

    def test_every_cited_id_exists_in_authorised_evidence(self):
        p, _, t = make_world()
        r = p.handle_request(t["district"], Q)
        allowed = set(r["provenance"]["evidence_ids"])
        for s in r["brief"]["sections"]:
            for c in s["claims"]:
                self.assertTrue(set(c["evidence_ids"]) <= allowed)

    def test_provenance_records_model_prompt_versions_data_classes(self):
        p, _, t = make_world()
        pv = p.handle_request(t["state"], Q)["provenance"]
        self.assertEqual(pv["model"], "mock-deterministic-1")
        self.assertEqual(pv["prompt_versions"]["evidence_analyst"], "1.0.0")
        self.assertEqual(pv["data_classes"], ["SYNTHETIC"])

    def test_audit_ledger_records_ai_request_and_review(self):
        p, _, t = make_world()
        r = p.handle_request(t["state"], Q)
        p.submit_review(t["state"], {"brief_id": r["brief"]["brief_id"], "decision": "NEEDS_MORE_EVIDENCE", "note": "check audit source"})
        ev = {e["event_type"]: e for e in p.ledger.entries()}
        ai = ev["AI_REQUEST"]
        for k in ("model", "prompt_versions", "evidence_ids", "validation_passed"):
            self.assertIn(k, ai["payload"])
        self.assertTrue(ai["timestamp"] and ai["request_id"] == r["request_id"])
        self.assertEqual(ev["HUMAN_REVIEW"]["payload"]["decision"], "NEEDS_MORE_EVIDENCE")
        self.assertEqual(p.ledger.verify(), (True, None))
        self.assertEqual(p.get_brief(r["brief"]["brief_id"])["review"]["status"], "NEEDS_MORE_EVIDENCE")

    def test_abstention_produces_no_ai_calls(self):
        from ai.evidence_store import EvidenceStore, build_demo_store, RAICHUR
        calls = []
        from ai.provider import MockProvider

        class Spy(MockProvider):
            def complete(self, **kw):
                calls.append(1)
                return super().complete(**kw)
        p, _, t = make_world(Spy())
        p.store = EvidenceStore([x for x in build_demo_store()._by_id.values() if x["district_id"] != RAICHUR])
        r = p.handle_request(t["state"], Q)
        self.assertEqual((r["status"], r["decision"]["status"], calls), ("ABSTAINED", "INSUFFICIENT_EVIDENCE", []))
        self.assertIn("NO_EVIDENCE", r["abstention"]["reason_codes"])

    def test_cache_hit_still_audited_and_gets_fresh_brief_id(self):
        p, _, t = make_world(cache=ResponseCache())
        a, b = p.handle_request(t["state"], Q), p.handle_request(t["state"], Q)
        self.assertTrue(b["provenance"]["cache_hit"])
        self.assertNotEqual(a["brief"]["brief_id"], b["brief"]["brief_id"])
        self.assertIn("AI_REQUEST_CACHE_HIT", [e["event_type"] for e in p.ledger.entries()])

    def test_file_backed_ledger(self):
        with tempfile.TemporaryDirectory() as td:
            path = os.path.join(td, "a.jsonl")
            p, _, t = make_world(ledger=AuditLedger(path))
            p.handle_request(t["state"], Q)
            with open(path) as f:
                self.assertGreaterEqual(len(f.readlines()), 1)

    def test_prompt_version_override_changes_recorded_version_and_still_validates(self):
        from ai.config import Config
        p, _, t = make_world(config=Config(prompt_overrides={"evidence_analyst": "1.1.0"}))
        r = p.handle_request(t["state"], Q)
        self.assertEqual(r["provenance"]["prompt_versions"]["evidence_analyst"], "1.1.0")
        self.assertTrue(r["validation"]["passed"])

    def test_numbers_in_brief_equal_deterministic_values(self):
        p, _, t = make_world()
        r = p.handle_request(t["state"], Q)
        ind = {i["indicator_id"]: i["value"] for i in r["analysis"]["indicators"]}
        for s in r["brief"]["sections"]:
            for c in s["claims"]:
                for n in c["numbers"]:
                    if n["ref"] in ind:
                        self.assertAlmostEqual(n["value"], ind[n["ref"]], places=2)


if __name__ == "__main__":
    unittest.main()
