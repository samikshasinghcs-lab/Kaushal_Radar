from datetime import date

from ai.config import Config
from ai.deterministic import build_bundle
from ai.evidence_store import REFERENCE_DATE, RAICHUR, build_demo_store
from ai.master_pipeline import KaushalAIPipeline
from ai.provider import MockProvider, ProviderManager, RateLimiter
from ai.retrieval import retrieve
from security.access_control import UserDirectory

CFG = Config()


def make_world(provider=None, cache=None, config=None, ledger=None):
    cfg = config or Config()
    d = UserDirectory()
    toks = {"state": d.register("state1", "STATE_OFFICER"),
            "district": d.register("dist1", "DISTRICT_OFFICER", [RAICHUR]),
            "other": d.register("dist2", "DISTRICT_OFFICER", ["KA-001"]),
            "auditor": d.register("aud1", "AUDITOR"), "analyst": d.register("ana1", "ANALYST", [RAICHUR])}
    pm = ProviderManager(provider or MockProvider(), cfg, sleep=lambda s: None, rate_limiter=RateLimiter(100000))
    p = KaushalAIPipeline(build_demo_store(), d, pm, ledger=ledger, cache=cache, config=cfg, reference_date=REFERENCE_DATE)
    return p, d, toks


def raichur_bundle(role="STATE_OFFICER", districts=(), config=None):
    cfg = config or Config()
    d = UserDirectory()
    t = d.register("u", role, districts or [RAICHUR])
    ident = d.authenticate(t)
    store = build_demo_store()
    r = retrieve(store, ident, RAICHUR)
    b = build_bundle(store, r.records, RAICHUR, "Raichur", cfg, REFERENCE_DATE)
    return store, r, b
