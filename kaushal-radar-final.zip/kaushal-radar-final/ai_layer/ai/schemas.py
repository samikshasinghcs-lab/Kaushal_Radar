"""Strict JSON-schema validation (small, dependency-free subset) and the AI-layer schemas."""
import re
from .exceptions import SchemaValidationError

_INF = float("inf")
_TYPES = {
    "object": lambda v: isinstance(v, dict),
    "array": lambda v: isinstance(v, list),
    "string": lambda v: isinstance(v, str),
    "number": lambda v: isinstance(v, (int, float)) and not isinstance(v, bool) and v == v and v not in (_INF, -_INF),
    "integer": lambda v: isinstance(v, int) and not isinstance(v, bool),
    "boolean": lambda v: isinstance(v, bool),
    "null": lambda v: v is None,
}


def _check(inst, schema, path, errors):
    t = schema.get("type")
    if t is not None:
        types = t if isinstance(t, list) else [t]
        if not any(_TYPES[x](inst) for x in types):
            errors.append(f"{path}: expected {types}, got {type(inst).__name__}")
            return
    if "enum" in schema and inst not in schema["enum"]:
        errors.append(f"{path}: value not in enum")
    if isinstance(inst, str):
        if "minLength" in schema and len(inst) < schema["minLength"]:
            errors.append(f"{path}: too short")
        if "maxLength" in schema and len(inst) > schema["maxLength"]:
            errors.append(f"{path}: too long")
        if "pattern" in schema and not re.search(schema["pattern"], inst):
            errors.append(f"{path}: does not match pattern")
    if _TYPES["number"](inst):
        if "minimum" in schema and inst < schema["minimum"]:
            errors.append(f"{path}: below minimum")
        if "maximum" in schema and inst > schema["maximum"]:
            errors.append(f"{path}: above maximum")
    if isinstance(inst, dict):
        for req in schema.get("required", []):
            if req not in inst:
                errors.append(f"{path}: missing required '{req}'")
        props = schema.get("properties", {})
        if schema.get("additionalProperties") is False:
            for k in inst:
                if k not in props:
                    errors.append(f"{path}: unexpected property '{k}'")
        for k, sub in props.items():
            if k in inst:
                _check(inst[k], sub, f"{path}.{k}", errors)
    if isinstance(inst, list):
        if "minItems" in schema and len(inst) < schema["minItems"]:
            errors.append(f"{path}: too few items")
        if "maxItems" in schema and len(inst) > schema["maxItems"]:
            errors.append(f"{path}: too many items")
        if "items" in schema:
            for i, item in enumerate(inst):
                _check(item, schema["items"], f"{path}[{i}]", errors)


def validate(instance, schema):
    errors = []
    _check(instance, schema, "$", errors)
    if errors:
        raise SchemaValidationError("; ".join(errors[:8]), details={"errors": errors})
    return instance


TASKS = ["evidence_analyst", "contradiction_analyst", "anomaly_explainer",
         "uncertainty_explainer", "recommendation_explainer", "policy_brief"]
UNITS = ["ratio", "percent", "persons", "seats", "postings", "per_1000", "count", "z_score", "rank", "days"]
REF_PATTERN = r"^[A-Z]{2,5}_[A-Z0-9_]+$"
EVIDENCE_PATTERN = r"^EV_[A-Z0-9_]+$"

NUMBER_SCHEMA = {
    "type": "object", "additionalProperties": False,
    "required": ["name", "value", "unit", "ref"],
    "properties": {
        "name": {"type": "string", "minLength": 1, "maxLength": 80},
        "value": {"type": "number"},
        "unit": {"type": "string", "enum": UNITS},
        "ref": {"type": "string", "pattern": REF_PATTERN, "maxLength": 80},
    },
}
CLAIM_SCHEMA = {
    "type": "object", "additionalProperties": False,
    "required": ["claim_id", "text", "kind", "evidence_ids", "indicator_ids", "numbers"],
    "properties": {
        "claim_id": {"type": "string", "pattern": r"^[A-Za-z0-9_\-]{1,40}$"},
        "text": {"type": "string", "minLength": 1, "maxLength": 900},
        "kind": {"type": "string", "enum": ["fact", "interpretation", "limitation", "suggestion"]},
        "evidence_ids": {"type": "array", "maxItems": 20,
                         "items": {"type": "string", "pattern": EVIDENCE_PATTERN, "maxLength": 80}},
        "indicator_ids": {"type": "array", "maxItems": 20,
                          "items": {"type": "string", "pattern": REF_PATTERN, "maxLength": 80}},
        "numbers": {"type": "array", "maxItems": 20, "items": NUMBER_SCHEMA},
    },
}
ANALYST_OUTPUT_SCHEMA = {
    "type": "object", "additionalProperties": False,
    "required": ["task", "prompt_version", "summary", "claims", "confidence", "abstain", "abstain_reason"],
    "properties": {
        "task": {"type": "string", "enum": TASKS},
        "prompt_version": {"type": "string", "pattern": r"^\d+\.\d+\.\d+$"},
        "summary": {"type": "string", "maxLength": 600},
        "claims": {"type": "array", "maxItems": 40, "items": CLAIM_SCHEMA},
        "confidence": {"type": "string", "enum": ["LOW", "MEDIUM", "HIGH"]},
        "abstain": {"type": "boolean"},
        "abstain_reason": {"type": ["string", "null"], "maxLength": 300},
    },
}
INTENTS = ["WHY_FLAGGED", "CONTRADICTIONS", "UNCERTAINTY", "INDICATORS", "FULL_BRIEF"]
QUERY_SCHEMA = {
    "type": "object", "additionalProperties": False,
    "required": ["intent", "district_id", "district_name"],
    "properties": {
        "intent": {"type": "string", "enum": INTENTS},
        "district_id": {"type": "string", "pattern": r"^KA-\d{3}$"},
        "district_name": {"type": "string", "maxLength": 60},
    },
}
REVIEW_DECISIONS = ["ACKNOWLEDGED", "NEEDS_MORE_EVIDENCE", "DISPUTED", "ESCALATED_FOR_HUMAN_DECISION"]
REVIEW_SCHEMA = {
    "type": "object", "additionalProperties": False,
    "required": ["brief_id", "decision"],
    "properties": {
        "brief_id": {"type": "string", "pattern": r"^BR_[a-f0-9]{8,32}$"},
        "decision": {"type": "string", "enum": REVIEW_DECISIONS},
        "note": {"type": "string", "maxLength": 500},
    },
}
