"""Append-only, hash-chained audit ledger. Secrets and personal data are never written."""
import hashlib
import json
import threading
from datetime import datetime, timezone

from . import privacy

_SECRET_KEYS = ("key", "token", "secret", "password", "authorization", "credential")


def _clean(obj):
    if isinstance(obj, dict):
        return {k: ("[REDACTED]" if any(s in str(k).lower() for s in _SECRET_KEYS) else _clean(v)) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_clean(x) for x in obj]
    if isinstance(obj, str):
        return privacy.redact(obj)
    return obj


class AuditLedger:
    GENESIS = "0" * 64

    def __init__(self, path=None, clock=None):
        self.path, self._clock = path, clock or (lambda: datetime.now(timezone.utc).isoformat())
        self._entries, self._lock = [], threading.Lock()

    def append(self, event_type, actor_id, request_id, payload=None):
        with self._lock:
            prev = self._entries[-1]["entry_hash"] if self._entries else self.GENESIS
            body = {"seq": len(self._entries) + 1, "timestamp": self._clock(), "event_type": event_type,
                    "actor_id": actor_id, "request_id": request_id, "payload": _clean(payload or {}), "prev_hash": prev}
            body["entry_hash"] = hashlib.sha256((prev + json.dumps(body, sort_keys=True, default=str)).encode()).hexdigest()
            self._entries.append(body)
            if self.path:
                with open(self.path, "a", encoding="utf-8") as f:
                    f.write(json.dumps(body, sort_keys=True, default=str) + "\n")
            return body

    def log_ai_request(self, request_id, actor_id, model, prompt_versions, evidence_ids, validation, extra=None):
        return self.append("AI_REQUEST", actor_id, request_id,
                           dict({"model": model, "prompt_versions": prompt_versions, "evidence_ids": sorted(evidence_ids),
                                 "validation_passed": validation["passed"],
                                 "violation_codes": sorted({x["code"] for t in validation["per_task"].values() for x in t["violations"]})},
                                **(extra or {})))

    def entries(self):
        return [dict(e) for e in self._entries]

    def verify(self):
        prev = self.GENESIS
        for i, e in enumerate(self._entries):
            body = {k: v for k, v in e.items() if k != "entry_hash"}
            h = hashlib.sha256((prev + json.dumps(body, sort_keys=True, default=str)).encode()).hexdigest()
            if e["prev_hash"] != prev or e["entry_hash"] != h:
                return False, i
            prev = e["entry_hash"]
        return True, None
