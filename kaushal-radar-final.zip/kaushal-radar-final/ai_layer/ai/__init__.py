"""Kaushal Radar AI decision-support layer (standard library only).

Deterministic calculations are authoritative; AI interpretation is advisory.
"""
__version__ = "0.1.0"
