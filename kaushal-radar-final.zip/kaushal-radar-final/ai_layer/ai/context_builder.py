"""Builds minimal, structured, privacy-checked model context with source metadata."""
from . import privacy
from security.data_minimisation import minimise_records


def _evidence(bundle, config, only_ids=None):
    recs = bundle.records if only_ids is None else [r for r in bundle.records if r["evidence_id"] in only_ids]
    return minimise_records(recs, config.max_context_records)


def build_context(task, bundle, config):
    base = {"task": task, "district": {"id": bundle.district_id, "name": bundle.district_name},
            "reference_date": bundle.reference_date.isoformat(), "data_classes": bundle.data_classes,
            "confidence": {"level": bundle.confidence["level"]}}
    b = bundle
    if task == "evidence_analyst":
        base.update(evidence=_evidence(b, config), indicators=list(b.indicators.values()), flag=b.flag)
    elif task == "contradiction_analyst":
        ids = {e for c in b.contradictions for e in c["evidence_ids"]}
        base.update(evidence=_evidence(b, config, ids), contradictions=b.contradictions,
                    indicators=[b.indicators[i] for i in ("IND_PLR", "IND_GVR") if i in b.indicators],
                    counts={"CNT_RECORDS": len(b.records)})
    elif task == "anomaly_explainer":
        base.update(anomalies=b.anomalies, peers_available=b.peer.get("n", 0),
                    min_peers=b.config.min_peers_for_stats, z_threshold=b.config.z_threshold)
    elif task == "uncertainty_explainer":
        base.update(stale=b.stale, missing_required=b.missing_required, missing_optional=b.missing_optional,
                    denominator_changes=b.denominator_changes, sensitivity=b.sensitivity,
                    confidence=b.confidence, record_count=len(b.records),
                    evidence=_evidence(b, config, {e for d in b.denominator_changes for e in d["evidence_ids"]}))
    elif task == "recommendation_explainer":
        base.update(decision=b.decision if hasattr(b, "decision") else {})
    elif task == "policy_brief":
        ids = {e for t in b.triggers for e in t["evidence_ids"]}
        base.update(triggers=b.triggers, evidence=_evidence(b, config, ids),
                    contradictions=b.contradictions, stale=b.stale, denominator_changes=b.denominator_changes,
                    missing_required=b.missing_required, missing_optional=b.missing_optional)
    else:
        raise KeyError(task)
    privacy.enforce(base, f"context[{task}]")
    return base
