"""Privacy layer: detect/block personal information before anything reaches a model."""
import re
from .exceptions import PrivacyViolation

BLOCKED_FIELD_NAMES = {"full_name", "first_name", "last_name", "person_name", "applicant_name", "candidate_name", "aadhaar", "aadhar", "pan", "phone", "mobile", "email",
                       "dob", "date_of_birth", "address", "voter_id", "passport", "bank_account", "ifsc"}
_EMAIL = re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b")
_PHONE = re.compile(r"(?<!\d)(?:\+91[\s-]?|0)?[6-9]\d{9}(?!\d)")
_PAN = re.compile(r"\b[A-Z]{5}\d{4}[A-Z]\b")
_AADHAAR_SEP = re.compile(r"(?<!\d)([2-9]\d{3})[\s-](\d{4})[\s-](\d{4})(?!\d)")
_AADHAAR_PLAIN = re.compile(r"(?<!\d)[2-9]\d{11}(?!\d)")

_D = [[0,1,2,3,4,5,6,7,8,9],[1,2,3,4,0,6,7,8,9,5],[2,3,4,0,1,7,8,9,5,6],[3,4,0,1,2,8,9,5,6,7],
      [4,0,1,2,3,9,5,6,7,8],[5,9,8,7,6,0,4,3,2,1],[6,5,9,8,7,1,0,4,3,2],[7,6,5,9,8,2,1,0,4,3],
      [8,7,6,5,9,3,2,1,0,4],[9,8,7,6,5,4,3,2,1,0]]
_P = [[0,1,2,3,4,5,6,7,8,9],[1,5,7,6,2,8,3,0,9,4],[5,8,0,3,7,9,6,1,4,2],[8,9,1,6,0,4,3,5,2,7],
      [9,4,5,3,1,2,6,8,7,0],[4,2,8,6,5,7,3,9,0,1],[2,7,9,3,8,0,6,4,1,5],[7,0,4,6,9,1,3,2,5,8]]


def verhoeff_valid(num):
    c = 0
    for i, ch in enumerate(reversed(num)):
        c = _D[c][_P[i % 8][int(ch)]]
    return c == 0


def verhoeff_generate(num):
    """Return the check digit for num (used to build valid test fixtures)."""
    c = 0
    for i, ch in enumerate(reversed(num)):
        c = _D[c][_P[(i + 1) % 8][int(ch)]]
    return str([0,4,3,2,1,5,6,7,8,9][c])


def find_pii(text):
    """Return a sorted list of PII *types* found (never the values)."""
    if not isinstance(text, str):
        return []
    found = set()
    if _EMAIL.search(text):
        found.add("EMAIL")
    if _PAN.search(text):
        found.add("PAN")
    if _PHONE.search(text):
        found.add("PHONE")
    for m in _AADHAAR_SEP.finditer(text):
        groups = [m.group(1), m.group(2), m.group(3)]
        if not all(1900 <= int(g) <= 2100 for g in groups):
            found.add("AADHAAR")
    for m in _AADHAAR_PLAIN.finditer(text):
        if verhoeff_valid(m.group(0)):
            found.add("AADHAAR")
    return sorted(found)


def redact(text):
    if not isinstance(text, str):
        return text
    text = _EMAIL.sub("[REDACTED_EMAIL]", text)
    text = _PAN.sub("[REDACTED_PAN]", text)
    text = _PHONE.sub("[REDACTED_PHONE]", text)
    text = _AADHAAR_SEP.sub("[REDACTED_ID]", text)
    return _AADHAAR_PLAIN.sub(lambda m: "[REDACTED_ID]" if verhoeff_valid(m.group(0)) else m.group(0), text)


def scan_obj(obj, path="$"):
    """Recursively scan strings and keys. Returns list of {'path','type'} (no values)."""
    hits = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            if isinstance(k, str) and k.lower() in BLOCKED_FIELD_NAMES:
                hits.append({"path": f"{path}.{k}", "type": "BLOCKED_FIELD"})
            hits += scan_obj(v, f"{path}.{k}")
    elif isinstance(obj, (list, tuple)):
        for i, v in enumerate(obj):
            hits += scan_obj(v, f"{path}[{i}]")
    elif isinstance(obj, str):
        hits += [{"path": path, "type": t} for t in find_pii(obj)]
    return hits


def enforce(obj, label="payload"):
    hits = scan_obj(obj)
    if hits:
        raise PrivacyViolation(f"personal information detected in {label}",
                               code="PII_DETECTED", details={"hits": hits[:10]})
    return obj
