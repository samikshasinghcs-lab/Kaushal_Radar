"""Karnataka district registry (names only; no statistics).

IDs here are positional (alphabetical) placeholders. Map them to the repository's real
district identifiers if they differ (see docs/INTEGRATION_NOTES.md).
"""
import re
import unicodedata

_NAMES = [
    "Bagalkot", "Ballari", "Belagavi", "Bengaluru Rural", "Bengaluru Urban", "Bidar",
    "Chamarajanagar", "Chikkaballapur", "Chikkamagaluru", "Chitradurga", "Dakshina Kannada",
    "Davanagere", "Dharwad", "Gadag", "Hassan", "Haveri", "Kalaburagi", "Kodagu", "Kolar",
    "Koppal", "Mandya", "Mysuru", "Raichur", "Ramanagara", "Shivamogga", "Tumakuru", "Udupi",
    "Uttara Kannada", "Vijayanagara", "Vijayapura", "Yadgir",
]
DISTRICTS = {f"KA-{i:03d}": n for i, n in enumerate(sorted(_NAMES), start=1)}
NAME_TO_ID = {n.lower(): i for i, n in DISTRICTS.items()}
ID_PATTERN = re.compile(r"^KA-\d{3}$")


def is_valid_id(district_id):
    return isinstance(district_id, str) and bool(ID_PATTERN.match(district_id)) and district_id in DISTRICTS


def name_of(district_id):
    return DISTRICTS[district_id]


def find_districts_in_text(text):
    """Return ordered unique district ids whose names appear as whole words in text."""
    t = unicodedata.normalize("NFKC", text).lower()
    found = []
    for name, did in sorted(NAME_TO_ID.items(), key=lambda kv: -len(kv[0])):
        if re.search(r"(?<![a-z])" + re.escape(name) + r"(?![a-z])", t) and did not in found:
            found.append(did)
    return found


def all_names():
    return list(DISTRICTS.values())
