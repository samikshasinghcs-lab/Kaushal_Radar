"""Exception hierarchy for the Kaushal Radar AI layer."""


class KRError(Exception):
    code = "KR_ERROR"

    def __init__(self, message="", *, code=None, details=None):
        super().__init__(message)
        if code:
            self.code = code
        self.details = details or {}


class ProviderError(KRError):
    code = "PROVIDER_ERROR"


class ProviderTimeout(ProviderError):
    code = "PROVIDER_TIMEOUT"


class ProviderRateLimit(ProviderError):
    code = "PROVIDER_RATE_LIMIT"


class ProviderFatal(ProviderError):
    """Non-retryable provider failure (bad credentials, bad request)."""
    code = "PROVIDER_FATAL"


class ProviderUnavailable(ProviderError):
    """Raised after bounded retries are exhausted. Never silently succeeds."""
    code = "PROVIDER_UNAVAILABLE"


class MalformedOutput(KRError):
    code = "MALFORMED_OUTPUT"


class SchemaValidationError(KRError):
    code = "SCHEMA_INVALID"


class AuthenticationError(KRError):
    code = "AUTH_FAILED"


class AccessDenied(KRError):
    code = "ACCESS_DENIED"


class InputRejected(KRError):
    code = "INPUT_REJECTED"


class PromptInjectionDetected(InputRejected):
    code = "PROMPT_INJECTION"


class PrivacyViolation(InputRejected):
    code = "PRIVACY_VIOLATION"


class ConfigError(KRError):
    code = "CONFIG_ERROR"
