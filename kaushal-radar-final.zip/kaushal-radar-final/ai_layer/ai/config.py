"""Configuration. Secrets come from environment variables only and are never stored on Config."""
import os
from dataclasses import dataclass, field, replace


@dataclass
class Config:
    provider: str = "mock"                 # "mock" | "anthropic"
    model: str = "mock-deterministic-1"
    request_timeout_s: float = 20.0
    max_retries: int = 2
    retry_base_delay_s: float = 0.5
    retry_max_delay_s: float = 8.0
    rate_limit_per_minute: int = 30
    cache_ttl_s: int = 900
    min_evidence_records: int = 4
    numeric_rel_tol: float = 0.005
    numeric_abs_tol: float = 0.01
    z_threshold: float = 2.0
    min_peers_for_stats: int = 5
    flag_multiplier: float = 1.5
    contradiction_rel_threshold: float = 0.10
    tension_placement_pct: float = 75.0
    tension_ratio: float = 6.0
    rank_instability: int = 2
    max_question_chars: int = 500
    max_context_records: int = 60
    max_note_chars: int = 500
    prompt_overrides: dict = field(default_factory=dict)  # {task: version}

    def with_changes(self, **kw):
        return replace(self, **kw)

    def __repr__(self):  # never include secrets (none are stored)
        return f"Config(provider={self.provider!r}, model={self.model!r})"


def from_env(env=None):
    env = os.environ if env is None else env
    return Config(
        provider=env.get("KR_PROVIDER", "mock"),
        model=env.get("KR_MODEL", "claude-sonnet-5-5" if env.get("KR_PROVIDER") == "anthropic" else "mock-deterministic-1"),
        request_timeout_s=float(env.get("KR_TIMEOUT_S", "20")),
        max_retries=int(env.get("KR_MAX_RETRIES", "2")),
        rate_limit_per_minute=int(env.get("KR_RATE_LIMIT_PER_MIN", "30")),
    )


def get_api_key(env=None):
    """API key is read at call time from the environment; never cached, never logged."""
    env = os.environ if env is None else env
    return env.get("ANTHROPIC_API_KEY")
