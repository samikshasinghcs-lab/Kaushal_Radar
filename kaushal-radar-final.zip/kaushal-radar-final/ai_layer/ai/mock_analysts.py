"""Deterministic offline 'interpreter' used by MockProvider.

It reads ONLY the supplied context and writes schema-valid claims. It is template based and is a
stand-in for a language model, not a model. Its outputs still pass through every guard.
"""
LABELS = {"graduates_total": "graduates", "vacancies_total": "vacancies", "placed_total": "placements",
          "working_age_population": "working-age population", "labour_force": "labour force",
          "training_seats": "training seats", "trained_total": "trained persons"}


def fmt(v):
    if isinstance(v, float) and v != int(v):
        return f"{v:,.2f}"
    return f"{int(v):,}" if float(v) == int(v) and abs(v) >= 1000 else (f"{float(v):.2f}" if isinstance(v, float) else str(v))


def _num(name, value, unit, ref):
    return {"name": name, "value": value, "unit": unit, "ref": ref}


def _claim(cid, text, kind, ev=(), ind=(), nums=()):
    ev, ind = set(ev), set(ind)
    for n in nums:  # every number's reference must be cited by the claim
        (ev if n["ref"].startswith("EV_") else ind).add(n["ref"])
    return {"claim_id": cid, "text": text, "kind": kind, "evidence_ids": sorted(ev),
            "indicator_ids": sorted(ind), "numbers": list(nums)}


def _wrap(task, version, ctx, summary, claims):
    return {"task": task, "prompt_version": version, "summary": summary, "claims": claims,
            "confidence": ctx.get("confidence", {}).get("level", "LOW"), "abstain": False, "abstain_reason": None}


def _evidence_analyst(ctx, ver):
    name = ctx["district"]["name"]
    ind = {i["indicator_id"]: i for i in ctx["indicators"]}
    ev = {e["evidence_id"]: e for e in ctx["evidence"]}
    claims = []
    rnd = (lambda x: f"{x:.1f}") if ver.startswith("1.1") else fmt
    if "IND_GVR" in ind:
        gid, vid = ind["IND_GVR"]["inputs"]
        g, v, r = ev[gid]["value"], ev[vid]["value"], ind["IND_GVR"]["value"]
        fl, nums, ids = ctx["flag"], [_num("graduates_total", g, "persons", gid), _num("vacancies_total", v, "postings", vid),
                                       _num("graduate_to_vacancy_ratio", r, "ratio", "IND_GVR")], ["IND_GVR"]
        if fl["status"] in ("FLAGGED", "NOT_FLAGGED"):
            verb = "meets" if fl["status"] == "FLAGGED" else "does not meet"
            tail = (f" This {verb} the deterministic flag rule (threshold {fmt(fl['threshold'])}; peer median {fmt(fl['peer_median'])}).")
            nums += [_num("flag_threshold", fl["threshold"], "ratio", "IND_FLAG_THRESHOLD_GVR"),
                     _num("peer_median", fl["peer_median"], "ratio", "IND_PEER_MEDIAN_GVR")]
            ids += ["IND_FLAG_THRESHOLD_GVR", "IND_PEER_MEDIAN_GVR"]
        else:
            tail = " The flag rule could not be assessed because too few peer districts were available."
        claims.append(_claim("EA_1", f"{name} has {fmt(g)} graduates against {fmt(v)} vacancies, a graduate-to-vacancy ratio of {rnd(r)}." + tail,
                             "fact", [gid, vid], ids, nums))
    if "IND_PLR" in ind and "IND_TUR" in ind:
        pid, tid = ind["IND_PLR"]["inputs"]
        tid2, sid = ind["IND_TUR"]["inputs"]
        p, t, s = ev[pid]["value"], ev[tid]["value"], ev[sid]["value"]
        claims.append(_claim("EA_2", f"The placement rate is {fmt(ind['IND_PLR']['value'])}% ({fmt(p)} placed of {fmt(t)} trained) and training seat utilisation is {fmt(ind['IND_TUR']['value'])}% ({fmt(t)} trained in {fmt(s)} seats).",
                             "fact", [pid, tid, sid], ["IND_PLR", "IND_TUR"],
                             [_num("placement_rate_pct", ind["IND_PLR"]["value"], "percent", "IND_PLR"),
                              _num("training_utilisation_pct", ind["IND_TUR"]["value"], "percent", "IND_TUR"),
                              _num("placed_total", p, "persons", pid), _num("trained_total", t, "persons", tid),
                              _num("training_seats", s, "seats", sid)]))
    if "IND_GVR" in ind and ctx["flag"]["status"] == "FLAGGED":
        gid, vid = ind["IND_GVR"]["inputs"]
        claims.append(_claim("EA_3", "The indicators are consistent with graduate supply exceeding local vacancy absorption; this is an interpretation of the cited indicators and may reflect factors not present in the evidence.",
                             "interpretation", [gid, vid], ["IND_GVR"]))
    return _wrap("evidence_analyst", ver, ctx, f"Supporting signals for {name}.", claims)


def _contradiction_analyst(ctx, ver):
    name = ctx["district"]["name"]
    ev = {e["evidence_id"]: e for e in ctx["evidence"]}
    claims = []
    for i, c in enumerate(ctx["contradictions"], 1):
        cid = c["contradiction_id"]
        if c["type"] == "CROSS_INDICATOR_TENSION":
            ind = {x["indicator_id"]: x for x in ctx["indicators"]}
            claims.append(_claim(f"CA_{i}", f"Placement rate {fmt(ind['IND_PLR']['value'])}% is high while the graduate-to-vacancy ratio is {fmt(ind['IND_GVR']['value'])}. Type {c['type']}: high placement alongside low vacancy absorption may reflect placements outside the district or differing definitions, and needs investigation.",
                                 "fact", c["evidence_ids"], ["IND_PLR", "IND_GVR", cid],
                                 [_num("placement_rate_pct", ind["IND_PLR"]["value"], "percent", "IND_PLR"),
                                  _num("graduate_to_vacancy_ratio", ind["IND_GVR"]["value"], "ratio", "IND_GVR")]))
            continue
        a, b = c["evidence_ids"]
        why = ("the records differ in " + ", ".join(c["reasons"]).replace("_", " ") + ", so the gap may reflect measurement rather than a real conflict."
               if c["type"] == "MEASUREMENT_DIFFERENCE" else
               "the records share definition, period and denominator basis, so measurement does not explain the gap and it needs investigation.")
        claims.append(_claim(f"CA_{i}", f"{c['metric']} differs between {a} (source {c['source_ids'][0]}) at {fmt(c['values'][0])} and {b} (source {c['source_ids'][1]}) at {fmt(c['values'][1])}, a gap of {fmt(c['delta_pct'])}%. Type {c['type']}: {why}",
                             "fact", [a, b], [cid],
                             [_num("value_a", ev[a]["value"], ev[a]["unit"], a), _num("value_b", ev[b]["value"], ev[b]["unit"], b),
                              _num("gap_pct", c["delta_pct"], "percent", cid)]))
    if not claims:
        claims.append(_claim("CA_0", f"No contradictions were detected by the deterministic cross-source and cross-indicator checks across {ctx['counts']['CNT_RECORDS']} evidence records.",
                             "limitation", [], [], [_num("records", ctx["counts"]["CNT_RECORDS"], "count", "CNT_RECORDS")]))
    return _wrap("contradiction_analyst", ver, ctx, f"Contradiction review for {name}.", claims)


def _anomaly_explainer(ctx, ver):
    name = ctx["district"]["name"]
    claims = []
    for i, a in enumerate(ctx["anomalies"], 1):
        aid = a["anomaly_id"]
        claims.append(_claim(f"AE_{i}", f"{a['metric']} for {name} is {fmt(a['value'])}, which is {fmt(abs(a['z']))} standard deviations {a['direction']} the peer mean of {fmt(a['peer_mean'])} (peer standard deviation {fmt(a['peer_sd'])}); the deterministic z-score test (threshold {fmt(ctx['z_threshold'])}) lists it as an anomaly.",
                             "fact", a["inputs"], [a["indicator_id"], aid],
                             [_num("value", a["value"], a["unit"], a["indicator_id"]), _num("z_score", a["z"], "z_score", aid),
                              _num("peer_mean", a["peer_mean"], a["unit"], aid + "_MEAN"),
                              _num("peer_sd", a["peer_sd"], a["unit"], aid + "_SD"),
                              _num("z_threshold", ctx["z_threshold"], "z_score", "CFG_Z_THRESHOLD")]))
    if not claims:
        if ctx["peers_available"] < ctx["min_peers"]:
            claims.append(_claim("AE_0", f"Anomaly tests were not run because only {ctx['peers_available']} peer districts were available (minimum {ctx['min_peers']}).",
                                 "limitation", [], [], [_num("peers", ctx["peers_available"], "count", "CNT_PEERS"),
                                                        _num("min_peers", ctx["min_peers"], "count", "CFG_MIN_PEERS")]))
        else:
            claims.append(_claim("AE_0", f"The deterministic z-score tests found no statistical anomalies against {ctx['peers_available']} peer districts (threshold {fmt(ctx['z_threshold'])}).",
                                 "limitation", [], [], [_num("peers", ctx["peers_available"], "count", "CNT_PEERS"),
                                                        _num("z_threshold", ctx["z_threshold"], "z_score", "CFG_Z_THRESHOLD")]))
    return _wrap("anomaly_explainer", ver, ctx, f"Anomaly explanation for {name}.", claims)


def _uncertainty_explainer(ctx, ver):
    name = ctx["district"]["name"]
    claims, n = [], 0

    def nid():
        nonlocal n
        n += 1
        return f"UE_{n}"
    cls = ", ".join(ctx["data_classes"]) or "NONE"
    claims.append(_claim(nid(), f"The {fmt(ctx['record_count'])} evidence records used here carry data class: {cls}. SYNTHETIC data is test data and not official statistics." if "SYNTHETIC" in ctx["data_classes"]
                         else f"The {fmt(ctx['record_count'])} evidence records used here carry data class: {cls}.", "limitation", [], [],
                         [_num("records", ctx["record_count"], "count", "CNT_RECORDS")]))
    for s in ctx["stale"]:
        claims.append(_claim(nid(), f"{s['evidence_id']} (source {s['source_id']}) is {fmt(s['age_days'])} days old, beyond its {fmt(s['max_age_days'])}-day freshness limit.",
                             "fact", [s["evidence_id"]], [s["stale_id"]],
                             [_num("age_days", s["age_days"], "days", s["stale_id"]),
                              _num("max_age_days", s["max_age_days"], "days", s["stale_id"] + "_MAX")]))
    if ctx["missing_required"]:
        claims.append(_claim(nid(), "Required evidence is missing: " + ", ".join(ctx["missing_required"]) + ".", "limitation"))
    if ctx["missing_optional"]:
        claims.append(_claim(nid(), "Optional evidence is missing: " + ", ".join(ctx["missing_optional"]) + "; the related denominator comparison could not be run.", "limitation"))
    ev = {e["evidence_id"]: e for e in ctx["evidence"]}
    for d in ctx["denominator_changes"]:
        a, b = d["evidence_ids"]
        claims.append(_claim(nid(), f"The denominator basis for {d['metric']} differs between {a} ({d['bases'][0]}) and {b} ({d['bases'][1]}): {fmt(d['values'][0])} versus {fmt(d['values'][1])}, a gap of {fmt(d['delta_pct'])}%.",
                             "fact", [a, b], [], [_num("value_a", ev[a]["value"], ev[a]["unit"], a), _num("value_b", ev[b]["value"], ev[b]["unit"], b),
                                              _num("gap_pct", d["delta_pct"], "percent", d["denominator_id"])]))
    for v in ctx["sensitivity"]["vacancy_scenarios"]:
        outcome = "no longer be met" if v["flips"] else "still be met" if v["alt_flag"] == "FLAGGED" else "still not be met"
        claims.append(_claim(nid(), f"Using the alternative vacancy figure from {v['evidence_id']}, the graduate-to-vacancy ratio would be {fmt(v['alt_ratio'])} and the flag rule would {outcome}.",
                             "fact", [v["evidence_id"]], [v["sens_id"]], [_num("alt_ratio", v["alt_ratio"], "ratio", v["sens_id"])]))
    rk = ctx["sensitivity"]["ranking"]
    if rk:
        word = "unstable" if rk["unstable"] else "stable"
        claims.append(_claim(nid(), f"Ranking is {word} across denominators: rank {rk['rank_gpc']} of {rk['n']} per working-age population versus rank {rk['rank_gpl']} of {rk['n']} per labour force.",
                             "fact", [], ["SENS_RANK_GPC", "SENS_RANK_GPL", "SENS_RANK_N"],
                             [_num("rank_gpc", rk["rank_gpc"], "rank", "SENS_RANK_GPC"), _num("rank_gpl", rk["rank_gpl"], "rank", "SENS_RANK_GPL"),
                              _num("n", rk["n"], "count", "SENS_RANK_N")]))
    conf = ctx["confidence"]
    claims.append(_claim(nid(), f"Overall evidence confidence is {conf['level']}; contributing factors: " + (", ".join(conf["reasons"]) or "none") + ".", "limitation"))
    return _wrap("uncertainty_explainer", ver, ctx, f"Uncertainty review for {name}.", claims)


def _recommendation_explainer(ctx, ver):
    d, name = ctx["decision"], ctx["district"]["name"]
    claims = [_claim("RE_1", f"The decision engine status for {name} is {d['status']} (reason codes: " + (", ".join(d["reason_codes"]) or "none") + ").", "fact", [], ["DEC_STATUS"]),
              _claim("RE_2", "This status is advisory and requires human review before any departmental decision.", "limitation")]
    return _wrap("recommendation_explainer", ver, ctx, f"Decision status explanation for {name}.", claims)


_SUGGEST = {
    "FLAG": "Review local vacancy and graduate-supply conditions behind the ratio that met the deterministic flag rule.",
    "CONTRADICTION_GENUINE": "Ask the data owners to reconcile the two disagreeing records for the same metric.",
    "CONTRADICTION_MEASUREMENT_DIFFERENCE": "Check whether the definitions, periods or denominator bases of the two records are comparable.",
    "CONTRADICTION_CROSS_INDICATOR_TENSION": "Examine where placed candidates are employed, inside or outside the district, to understand the placement versus vacancy tension.",
    "STALE": "Request a refresh of this record from its source owner.",
    "DENOMINATOR": "Confirm which denominator basis is authoritative for this metric.",
}


def _policy_brief(ctx, ver):
    name = ctx["district"]["name"]
    claims = [_claim(f"PB_{i}", _SUGGEST[t["kind"]], "suggestion", t["evidence_ids"], t["indicator_ids"])
              for i, t in enumerate(ctx["triggers"], 1)]
    if ctx["missing_required"]:
        claims.append(_claim("PB_M", "Obtain the missing required evidence: " + ", ".join(ctx["missing_required"]) + ".", "suggestion"))
    return _wrap("policy_brief", ver, ctx, f"Suggested investigations for {name}.", claims)


_TASKS = {"evidence_analyst": _evidence_analyst, "contradiction_analyst": _contradiction_analyst,
          "anomaly_explainer": _anomaly_explainer, "uncertainty_explainer": _uncertainty_explainer,
          "recommendation_explainer": _recommendation_explainer, "policy_brief": _policy_brief}


def generate(task, context, prompt_version):
    return _TASKS[task](context, prompt_version)
