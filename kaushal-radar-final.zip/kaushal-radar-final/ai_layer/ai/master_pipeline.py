"""Master pipeline: authenticate -> validate -> retrieve -> deterministic -> AI -> guards -> gate -> review -> audit."""
import copy
import hashlib
import uuid
from datetime import date, datetime, timezone

from . import abstention, audit as audit_mod, cache as cache_mod, context_builder, districts, privacy
from . import hallucination_guard, natural_language_query, numeric_guard, policy_brief, source_grounding
from .config import Config
from .decision_gate import DecisionGate
from .deterministic import build_bundle
from .evidence_store import evidence_fingerprint
from .exceptions import (AccessDenied, AuthenticationError, InputRejected, PrivacyViolation, PromptInjectionDetected,
                         ProviderUnavailable, KRError)
from .prompts import DEFAULT_VERSIONS
from .retrieval import retrieve, public_exclusions
from .schemas import REVIEW_SCHEMA, validate
from security import input_validation, prompt_injection, output_safety
from security.access_control import authorize

TASK_ORDER = ["evidence_analyst", "contradiction_analyst", "anomaly_explainer", "uncertainty_explainer",
              "recommendation_explainer", "policy_brief"]


class KaushalAIPipeline:
    def __init__(self, store, directory, provider_manager, ledger=None, cache=None, gate=None, config=None,
                 reference_date=None, now_fn=None):
        self.store, self.directory, self.pm = store, directory, provider_manager
        self.config = config or provider_manager.config or Config()
        self.ledger = ledger or audit_mod.AuditLedger()
        self.cache, self.gate = cache, gate or DecisionGate()
        self.reference_date = reference_date
        self._now = now_fn or (lambda: datetime.now(timezone.utc).isoformat())
        self._briefs = {}

    # ---- helpers -------------------------------------------------------------------------
    def _ref(self):
        return self.reference_date or date.today()

    def _err(self, rid, status, code, message, actor=None, event=None, payload=None):
        self.ledger.append(event or status, actor, rid, dict(payload or {}, code=code))
        return {"request_id": rid, "status": status, "error": {"code": code, "message": message},
                "brief": None, "human_review": {"required": True, "status": "NOT_APPLICABLE"}}

    def _validate_output(self, task, output, bundle, decision):
        v = []
        v += source_grounding.check(output, bundle, self.store)
        v += numeric_guard.check(output, bundle, self.config)
        v += hallucination_guard.check(output, bundle, decision if task == "recommendation_explainer" else None)
        v += output_safety.check_output(output)
        if output.get("abstain"):
            v.append({"code": "UNEXPECTED_ABSTAIN", "claim_id": "output", "detail": "model abstained although evidence suffices"})
        return {"passed": not v, "violations": v}

    # ---- main entry ----------------------------------------------------------------------
    def handle_request(self, token, payload):
        rid = uuid.uuid4().hex[:16]
        try:
            identity = self.directory.authenticate(token)
        except AuthenticationError:
            return self._err(rid, "AUTH_FAILED", "AUTH_FAILED", "Authentication failed.", event="AUTH_FAILED")
        actor = identity.user_id
        qhash = hashlib.sha256(repr(payload).encode()).hexdigest()[:16] if not isinstance(payload, dict) else \
            hashlib.sha256(str(payload.get("question", "")).encode()).hexdigest()[:16]
        try:
            req = input_validation.validate_request(payload, self.config.max_question_chars)
            prompt_injection.assert_clean(req.question, "question")
            privacy.enforce({"question": req.question}, "question")
            query = natural_language_query.parse_question(req.question, req.district_id)
        except PromptInjectionDetected as e:
            return self._err(rid, "REJECTED_INJECTION", e.code, "Request rejected: possible prompt injection.", actor,
                             "INPUT_REJECTED", {"question_sha256": qhash, "matches": e.details.get("matches")})
        except PrivacyViolation as e:
            return self._err(rid, "REJECTED_PRIVACY", e.code, "Request rejected: personal information detected.", actor,
                             "INPUT_REJECTED", {"question_sha256": qhash, "types": [h["type"] for h in e.details.get("hits", [])]})
        except InputRejected as e:
            return self._err(rid, "REJECTED_INPUT", e.code, f"Request rejected: {e}", actor, "INPUT_REJECTED",
                             {"question_sha256": qhash})
        did = query["district_id"]
        try:
            authorize(identity, "query_district", did)
        except AccessDenied as e:
            return self._err(rid, "ACCESS_DENIED", e.code, "Access denied.", actor, "ACCESS_DENIED",
                             {"district_id": did, "question_sha256": qhash})

        retrieval = retrieve(self.store, identity, did)
        bundle = build_bundle(self.store, retrieval.records, did, query["district_name"], self.config, self._ref())
        absent = abstention.decide(bundle, self.config)
        decision = self.gate.evaluate(bundle, absent)
        bundle.decision = decision
        analysis = self._analysis(bundle)
        prov = {"model": self.pm.model, "prompt_versions": {t: self.config.prompt_overrides.get(t, DEFAULT_VERSIONS[t]) for t in TASK_ORDER},
                "evidence_ids": sorted(retrieval.ids()), "data_classes": bundle.data_classes, **public_exclusions(retrieval),
                "cache_hit": False}
        base = {"request_id": rid, "query": query, "decision": decision, "analysis": analysis, "provenance": prov}
        internal_excl = retrieval.excluded

        if absent.abstain:
            brief_id = self._new_brief(did)
            resp = dict(base, status="ABSTAINED", abstention=abstention.response_for(absent),
                        validation={"passed": False, "per_task": {}, "rejected_tasks": []},
                        decision=self.gate.finalise(decision, False),
                        brief={"brief_id": brief_id, "district": {"id": did, "name": query["district_name"]},
                               "decision_status": decision["status"], "verification_status": "NOT_GENERATED_INSUFFICIENT_EVIDENCE",
                               "sections": [], "human_review": {"required": True, "status": "PENDING"}},
                        human_review={"required": True, "status": "PENDING"})
            self._store_brief(brief_id, did, resp["brief"])
            self.ledger.append("AI_REQUEST_ABSTAINED", actor, rid, {"district_id": did, "reason_codes": absent.reason_codes,
                                                                    "evidence_ids": sorted(retrieval.ids()), "excluded": internal_excl,
                                                                    "question_sha256": qhash})
            return resp

        ckey = None
        if self.cache:
            ckey = cache_mod.make_key(identity, did, query["intent"], evidence_fingerprint(retrieval.records),
                                      prov["prompt_versions"], prov["model"], self._ref())
            hit = self.cache.get(ckey)
            if hit:
                brief_id = self._new_brief(did)
                hit["request_id"], hit["provenance"]["cache_hit"] = rid, True
                hit["brief"]["brief_id"] = brief_id
                hit["brief"]["human_review"] = {"required": True, "status": "PENDING"}
                self._store_brief(brief_id, did, hit["brief"])
                self.ledger.append("AI_REQUEST_CACHE_HIT", actor, rid, {"district_id": did, "evidence_ids": sorted(retrieval.ids())})
                return hit

        results = {}
        try:
            for task in TASK_ORDER:
                ctx = context_builder.build_context(task, bundle, self.config)
                call = self.pm.complete_json(task, ctx)
                results[task] = {"output": call.output, "attempts": call.attempts,
                                 "validation": self._validate_output(task, call.output, bundle, decision)}
        except ProviderUnavailable as e:
            self.ledger.append("AI_REQUEST_FAILED", actor, rid, {"district_id": did, "code": e.code, "details": e.details,
                                                                 "completed_tasks": list(results)})
            return dict(base, status="FAILED_PROVIDER", error={"code": e.code, "message": "AI provider unavailable; no AI output was produced."},
                        decision=self.gate.finalise(decision, False), brief=None,
                        validation={"passed": False, "per_task": {t: r["validation"] for t, r in results.items()}, "rejected_tasks": list(results)},
                        human_review={"required": True, "status": "NOT_APPLICABLE"})
        except KRError as e:
            return self._err(rid, "REJECTED_INPUT", e.code, "Request could not be processed.", actor)

        passed = all(r["validation"]["passed"] for r in results.values())
        validation = {"passed": passed, "per_task": {t: r["validation"] for t, r in results.items()},
                      "rejected_tasks": [t for t, r in results.items() if not r["validation"]["passed"]]}
        brief_id = self._new_brief(did)
        brief = policy_brief.assemble(brief_id, bundle, decision, results, passed)
        self._store_brief(brief_id, did, brief)
        resp = dict(base, status="OK", decision=self.gate.finalise(decision, passed), validation=validation, brief=brief,
                    human_review=brief["human_review"])
        self.ledger.log_ai_request(rid, actor, self.pm.model, prov["prompt_versions"], retrieval.ids(), validation,
                                   {"district_id": did, "decision_status": decision["status"], "excluded": internal_excl,
                                    "question_sha256": qhash, "attempts": {t: r["attempts"] for t, r in results.items()}})
        if not passed:
            self.ledger.append("VALIDATION_FAILURE", actor, rid, {"rejected_tasks": validation["rejected_tasks"]})
        if self.cache and ckey:
            self.cache.put(ckey, resp)
        return resp

    def _analysis(self, b):
        return {"indicators": list(b.indicators.values()), "flag": b.flag, "peer": b.peer,
                "contradictions": b.contradictions, "anomalies": b.anomalies, "stale": b.stale,
                "missing_required": b.missing_required, "missing_optional": b.missing_optional,
                "denominator_changes": b.denominator_changes, "sensitivity": b.sensitivity, "confidence": b.confidence}

    def _new_brief(self, did):
        return "BR_" + uuid.uuid4().hex[:16]

    def _store_brief(self, brief_id, did, brief):
        self._briefs[brief_id] = {"district_id": did, "brief": brief, "review": {"status": "PENDING"}}

    # ---- human review --------------------------------------------------------------------
    def submit_review(self, token, payload):
        rid = uuid.uuid4().hex[:16]
        try:
            identity = self.directory.authenticate(token)
        except AuthenticationError:
            return self._err(rid, "AUTH_FAILED", "AUTH_FAILED", "Authentication failed.", event="AUTH_FAILED")
        try:
            if not isinstance(payload, dict):
                raise InputRejected("body must be an object", code="BAD_BODY")
            if any(isinstance(k, str) and k.lower() in input_validation.PRIVILEGE_KEYS for k in payload):
                raise InputRejected("privilege parameters rejected", code="PRIVILEGE_PARAMETER_REJECTED")
            from .exceptions import SchemaValidationError
            try:
                validate(payload, REVIEW_SCHEMA)
            except SchemaValidationError as e:
                raise InputRejected("invalid review request", code="INVALID_REVIEW_REQUEST") from e
            note = payload.get("note", "")
            privacy.enforce({"note": note}, "review note")
            prompt_injection.assert_clean(note, "review note")
        except InputRejected as e:
            return self._err(rid, "REJECTED_INPUT", e.code, f"Review rejected: {e}", identity.user_id, "REVIEW_REJECTED")
        rec = self._briefs.get(payload["brief_id"])
        if rec is None:
            return self._err(rid, "REJECTED_INPUT", "UNKNOWN_BRIEF", "Unknown brief.", identity.user_id, "REVIEW_REJECTED")
        try:
            authorize(identity, "review_brief", rec["district_id"])
        except AccessDenied as e:
            return self._err(rid, "ACCESS_DENIED", e.code, "Access denied.", identity.user_id, "ACCESS_DENIED",
                             {"brief_id": payload["brief_id"]})
        rec["review"] = {"status": payload["decision"], "reviewer": identity.user_id, "at": self._now(),
                         "note_present": bool(note)}
        rec["brief"]["human_review"] = {"required": True, "status": payload["decision"], "reviewer": identity.user_id}
        self.ledger.append("HUMAN_REVIEW", identity.user_id, rid,
                           {"brief_id": payload["brief_id"], "district_id": rec["district_id"], "decision": payload["decision"],
                            "note": note})
        return {"request_id": rid, "status": "REVIEW_RECORDED", "brief_id": payload["brief_id"], "review": rec["review"]}

    def get_brief(self, brief_id):
        return copy.deepcopy(self._briefs.get(brief_id))
