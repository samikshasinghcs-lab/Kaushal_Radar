"""Numeric integrity guard: every number must agree with deterministic source calculations."""
import re

_DATE = re.compile(r"\b\d{4}-\d{2}-\d{2}\b")
_PERIOD = re.compile(r"\b\d{4}-\d{2,4}\b")
_ID = re.compile(r"\b[A-Z]{2,5}_[A-Z0-9_]+\b")
_SNAKE = re.compile(r"\b[a-z]+(?:_[a-z0-9]+)+\b")
_DISTID = re.compile(r"\bKA-\d{3}\b")
_PER1000 = re.compile(r"\bper\s+1,?000\b", re.I)
_NUM = re.compile(r"(?<![A-Za-z_\d.])-?\d[\d,]*(?:\.\d+)?")


def extract_numbers(text):
    t = _DATE.sub(" ", text)
    for rx in (_PERIOD, _ID, _SNAKE, _DISTID, _PER1000):
        t = rx.sub(" ", t)
    out = []
    for m in _NUM.finditer(t):
        tok = m.group(0).rstrip(",").replace(",", "")
        try:
            out.append(float(tok))
        except ValueError:
            pass
    return out


def close(a, b, rel, ab):
    return abs(a - b) <= max(ab, rel * max(abs(a), abs(b)))


def check(output, bundle, config):
    refs = bundle.ref_values()
    allowed = bundle.allowed_numbers()
    rel, ab = config.numeric_rel_tol, config.numeric_abs_tol
    v = []
    texts = [("summary", output.get("summary", ""))] + [(c["claim_id"], c["text"]) for c in output["claims"]]
    for c in output["claims"]:
        for n in c["numbers"]:
            if n["ref"] not in refs:
                v.append({"code": "NUMBER_UNRESOLVED_REF", "claim_id": c["claim_id"], "detail": f"{n['ref']} unknown"})
                continue
            val, unit = refs[n["ref"]]
            if val is None:
                v.append({"code": "NUMBER_UNRESOLVED_REF", "claim_id": c["claim_id"], "detail": f"{n['ref']} has no numeric value"})
            elif unit != n["unit"]:
                v.append({"code": "NUMBER_UNIT_MISMATCH", "claim_id": c["claim_id"], "detail": f"{n['name']}: unit {n['unit']} != {unit}"})
            elif not close(n["value"], val, rel, ab):
                v.append({"code": "NUMBER_MISMATCH", "claim_id": c["claim_id"], "detail": f"{n['name']}: {n['value']} != authoritative {val}"})
    for where, text in texts:
        for x in extract_numbers(text):
            if not any(close(x, a, rel, ab) for a in allowed):
                v.append({"code": "NUMBER_NOT_IN_SOURCE", "claim_id": where, "detail": f"{x:g} matches no deterministic value"})
    return v
