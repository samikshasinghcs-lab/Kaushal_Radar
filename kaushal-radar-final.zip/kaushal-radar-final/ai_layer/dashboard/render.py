"""Renders an officer brief (from a REAL pipeline response) to static HTML. No client-side computation."""
import html


def render_brief(resp):
    e = html.escape
    b = resp["brief"]
    d = resp["decision"]
    css = ("body{font:15px system-ui,sans-serif;max-width:860px;margin:auto;padding:16px;color:#1a1a1a;background:#fff}"
           ".banner{background:#fff3cd;padding:10px;border-radius:6px;font-weight:600}.st{padding:8px;border-left:4px solid #555;background:#f4f4f4}"
           ".w{color:#b42318}.c{font-size:13px;color:#555}li{margin:6px 0}@media(prefers-color-scheme:dark){body{background:#111;color:#eee}"
           ".st{background:#222}.c{color:#aaa}.banner{background:#3a3000}}")
    parts = [f"<!doctype html><html lang=en><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'>"
             f"<title>Brief {e(b['district']['name'])}</title><style>{css}</style><h1>Diagnostic brief: {e(b['district']['name'])}</h1>"]
    if b.get("banner"):
        parts.append(f"<p class=banner>{e(b['banner'])}</p>")
    parts.append(f"<p class=st><b>Decision-engine status:</b> {e(d['status'])}<br><b>Reason codes:</b> {e(', '.join(d['reason_codes']) or 'none')}"
                 f"<br><b>Confidence:</b> {e(b['confidence'])}<br><b>Automated checks:</b> {e(b['verification_status'])}<br>"
                 f"<b>Human review:</b> {e(b['human_review']['status'])} (required)</p><p class=c>{e(b['verification_note'])}</p>")
    for s in b["sections"]:
        parts.append(f"<h2>{e(s['title'])}</h2>")
        if s["status"] != "VALIDATED":
            parts.append(f"<p class=w>AI text withheld - failed validation: {e(', '.join(s['violation_codes']))}</p>")
            continue
        parts.append("<ul>" + "".join(f"<li>{e(c['text'])}<div class=c>{e(c['kind'])} | evidence: {e(', '.join(c['evidence_ids']) or '-')}"
                                       f" | refs: {e(', '.join(c['indicator_ids']) or '-')}</div></li>" for c in s["claims"]) + "</ul>")
    parts.append("<h2>Limitations</h2><ul>" + "".join(f"<li>{e(x)}</li>" for x in b["limitations"]) + "</ul></html>")
    return "".join(parts)
